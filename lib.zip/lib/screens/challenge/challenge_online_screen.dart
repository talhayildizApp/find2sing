import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/game_room_model.dart';
import '../../models/match_intent_model.dart';
import '../../models/word_set_model.dart';
import '../../services/challenge_online_service.dart';
import '../../services/haptic_service.dart';
import '../../widgets/dual_column_selector.dart';

/// Challenge Online Game Screen with improved turn-based UX
/// - Clear active/passive player states
/// - Strong turn indicators with animations
/// - Locked selection when opponent plays
/// - Progress pressure visualization
/// - Turn/score change animations
/// - Online-specific rule feedback (auto-approve, +2 bonus)
class ChallengeOnlineScreen extends StatefulWidget {
  final String roomId;

  const ChallengeOnlineScreen({super.key, required this.roomId});

  @override
  State<ChallengeOnlineScreen> createState() => _ChallengeOnlineScreenState();
}

class _ChallengeOnlineScreenState extends State<ChallengeOnlineScreen>
    with TickerProviderStateMixin {
  final _gameService = ChallengeOnlineService();

  StreamSubscription<GameRoomModel?>? _roomSubscription;
  GameRoomModel? _room;
  List<ChallengeSongWithWords> _songs = [];
  List<String> _artists = [];
  String? _selectedArtist;
  String? _selectedSongId;
  bool _isSubmitting = false;
  bool _isFrozen = false;
  int _freezeSeconds = 0;
  Timer? _freezeTimer;
  Timer? _gameTimer;
  int _remainingSeconds = 0;

  // Animation controllers
  late AnimationController _pulseController;
  late AnimationController _turnChangeController;
  late AnimationController _scorePopController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _turnChangeAnimation;
  late Animation<double> _scorePopAnimation;

  // Feedback state
  String? _feedbackMessage;
  Color? _feedbackColor;
  bool _showFeedback = false;
  int? _lastMyScore;
  int? _lastOpponentScore;
  bool _showMyScorePop = false;
  bool _showOpponentScorePop = false;
  
  // Bonus toast state
  bool _showBonusToast = false;
  String? _bonusToastMessage;
  Color? _bonusToastColor;
  IconData? _bonusToastIcon;

  String? get _myUid => context.read<AuthProvider>().user?.uid;
  bool get _isMyTurn => _room?.turnUid == _myUid;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _listenToRoom();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _turnChangeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _turnChangeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _turnChangeController, curve: Curves.elasticOut),
    );

    _scorePopController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );

    _scorePopAnimation = Tween<double>(begin: 1.0, end: 1.3).animate(
      CurvedAnimation(parent: _scorePopController, curve: Curves.elasticOut),
    );
  }

  @override
  void dispose() {
    _roomSubscription?.cancel();
    _freezeTimer?.cancel();
    _gameTimer?.cancel();
    _pulseController.dispose();
    _turnChangeController.dispose();
    _scorePopController.dispose();
    super.dispose();
  }

  void _listenToRoom() {
    _roomSubscription = _gameService.streamRoom(widget.roomId).listen((room) async {
      if (room == null) return;

      final previousTurn = _room?.turnUid;
      final previousRoom = _room;

      setState(() => _room = room);

      // Load songs if not loaded
      if (_songs.isEmpty && room.challengeId != null) {
        final songs = await _gameService.getChallengeSongs(room.challengeId!);
        final artistSet = songs.map((s) => s.artist).toSet().toList()..sort();
        setState(() {
          _songs = songs;
          _artists = artistSet;
        });
      }

      // Start game timer for time race
      if (room.modeVariant == ModeVariant.timeRace && room.endsAt != null) {
        _startGameTimer(room.endsAt!);
      }

      // Detect turn change
      if (previousTurn != null && previousTurn != room.turnUid) {
        _turnChangeController.forward(from: 0);
        HapticFeedback.mediumImpact();
      }

      // Detect score changes
      if (previousRoom != null && _myUid != null) {
        final myPlayer = room.players[_myUid];
        final prevMyPlayer = previousRoom.players[_myUid];
        final opponentUid = room.players.keys.firstWhere((uid) => uid != _myUid, orElse: () => '');
        final opponentPlayer = opponentUid.isNotEmpty ? room.players[opponentUid] : null;
        final prevOpponentPlayer = opponentUid.isNotEmpty ? previousRoom.players[opponentUid] : null;

        if (myPlayer != null && prevMyPlayer != null && myPlayer.score != prevMyPlayer.score) {
          setState(() => _showMyScorePop = true);
          _scorePopController.forward(from: 0);
          Future.delayed(const Duration(milliseconds: 500), () {
            if (mounted) setState(() => _showMyScorePop = false);
          });
        }

        if (opponentPlayer != null && prevOpponentPlayer != null && opponentPlayer.score != prevOpponentPlayer.score) {
          setState(() => _showOpponentScorePop = true);
          _scorePopController.forward(from: 0);
          Future.delayed(const Duration(milliseconds: 500), () {
            if (mounted) setState(() => _showOpponentScorePop = false);
          });
        }
      }

      // Check game end
      if (room.isFinished) {
        _showGameEndDialog();
      } else if (room.status == RoomStatus.abandoned) {
        _showAbandonedDialog();
      }
    });
  }

  void _startGameTimer(DateTime endsAt) {
    _gameTimer?.cancel();
    _remainingSeconds = endsAt.difference(DateTime.now()).inSeconds.clamp(0, 999);

    _gameTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() => _remainingSeconds--);
        
        // Haptic warning in last 30 seconds
        if (_remainingSeconds <= 30 && _remainingSeconds % 10 == 0) {
          HapticFeedback.lightImpact();
        }
      } else {
        timer.cancel();
      }
    });
  }

  void _startFreeze(int seconds) {
    setState(() {
      _isFrozen = true;
      _freezeSeconds = seconds;
    });

    _freezeTimer?.cancel();
    _freezeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_freezeSeconds > 0) {
        setState(() => _freezeSeconds--);
      } else {
        setState(() => _isFrozen = false);
        HapticService.penaltyEnd();
        timer.cancel();
      }
    });
  }

  Future<void> _submitSelection() async {
    if (_selectedSongId == null || _selectedArtist == null || !_isMyTurn || _isFrozen || _myUid == null) return;

    setState(() => _isSubmitting = true);
    HapticService.selection();

    try {
      final result = await _gameService.submitSelection(
        roomId: widget.roomId,
        oderId: _myUid!,
        selectedSongId: _selectedSongId!,
      );

      if (result.isCorrect == true) {
        HapticService.correct();
        String message = 'Doğru! 🎉';
        
        // Check for special bonuses
        if (result.bonusApplied && result.points != null && result.points! > 1) {
          message = 'Doğru! +${result.points} puan 🔥';
          
          // +2 Steal bonus (Real Challenge - solved opponent's missed word)
          if (result.points == 2 && _room?.modeVariant == ModeVariant.real) {
            _showBonusToastMessage(
              'Rakibin kaçırdığı kelimeyi çözdün! +2',
              const Color(0xFFFFB958),
              Icons.catching_pokemon,
            );
          }
          // Comeback bonus (Relax mode - x2/x3 multiplier)
          else if (result.points! >= 2 && _room?.modeVariant == ModeVariant.relax) {
            _showBonusToastMessage(
              'Comeback Bonus! x${result.points}',
              const Color(0xFFFF6B6B),
              Icons.local_fire_department,
            );
          }
        }
        _showFeedbackBanner(message, const Color(0xFF4CAF50));
      } else {
        HapticService.wrong();
        _showFeedbackBanner('Yanlış! ❌', const Color(0xFFF85149));
        
        if (_room?.modeVariant == ModeVariant.timeRace) {
          _startFreeze(3);
        } else if (_room?.modeVariant == ModeVariant.relax) {
          _startFreeze(1);
        }
      }

      setState(() {
        _selectedArtist = null;
        _selectedSongId = null;
      });
    } catch (e) {
      debugPrint('Error submitting selection: $e');
      _showFeedbackBanner('Hata oluştu', Colors.red);
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  void _showFeedbackBanner(String message, Color color) {
    setState(() {
      _feedbackMessage = message;
      _feedbackColor = color;
      _showFeedback = true;
    });

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _showFeedback = false);
      }
    });
  }

  void _showBonusToastMessage(String message, Color color, IconData icon) {
    setState(() {
      _bonusToastMessage = message;
      _bonusToastColor = color;
      _bonusToastIcon = icon;
      _showBonusToast = true;
    });

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() => _showBonusToast = false);
      }
    });
  }

  void _showGameEndDialog() {
    if (_room == null || _myUid == null) return;

    final myPlayer = _room!.players[_myUid];
    final opponentUid = _room!.players.keys.firstWhere((uid) => uid != _myUid, orElse: () => '');
    if (opponentUid.isEmpty) return;
    
    final opponentPlayer = _room!.players[opponentUid];

    final myScore = myPlayer?.score ?? 0;
    final opponentScore = opponentPlayer?.score ?? 0;

    String emoji;
    String resultText;
    Color resultColor;
    List<Color> bgGradient;

    if (myScore > opponentScore) {
      emoji = '🏆';
      resultText = 'Kazandın!';
      resultColor = const Color(0xFF4CAF50);
      bgGradient = [const Color(0xFF4CAF50), const Color(0xFF66BB6A)];
    } else if (myScore < opponentScore) {
      emoji = '😔';
      resultText = 'Kaybettin';
      resultColor = const Color(0xFFF85149);
      bgGradient = [const Color(0xFFF85149), const Color(0xFFFF7B6B)];
    } else {
      emoji = '🤝';
      resultText = 'Berabere';
      resultColor = const Color(0xFFFFB958);
      bgGradient = [const Color(0xFFFFB958), const Color(0xFFFFCE54)];
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: bgGradient),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(emoji, style: const TextStyle(fontSize: 40)),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                resultText,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: resultColor,
                ),
              ),
              const SizedBox(height: 24),
              _buildResultScoreRow('Sen', myScore, myScore > opponentScore),
              const SizedBox(height: 12),
              _buildResultScoreRow(opponentPlayer?.name ?? 'Rakip', opponentScore, opponentScore > myScore),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.pop(context);
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF394272),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Kapat',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultScoreRow(String name, int score, bool isWinner) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isWinner ? const Color(0xFFE8F5E9) : const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(12),
        border: isWinner ? Border.all(color: const Color(0xFF4CAF50).withValues(alpha:0.3)) : null,
      ),
      child: Row(
        children: [
          if (isWinner)
            const Text('🏆 ', style: TextStyle(fontSize: 18)),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                fontSize: 16,
                fontWeight: isWinner ? FontWeight.w700 : FontWeight.w500,
                color: const Color(0xFF394272),
              ),
            ),
          ),
          Text(
            '$score',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: isWinner ? const Color(0xFF4CAF50) : const Color(0xFF6C6FA4),
            ),
          ),
        ],
      ),
    );
  }

  void _showAbandonedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            const Text('🚪', style: TextStyle(fontSize: 24)),
            const SizedBox(width: 10),
            const Text('Rakip Ayrıldı'),
          ],
        ),
        content: const Text('Rakip oyundan ayrıldı. Sen kazandın!'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  String _formatTime(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    if (_room == null) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFE8E0FF), Color(0xFFF5F3FF)],
            ),
          ),
          child: const Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                CircularProgressIndicator(color: Color(0xFFCAB7FF)),
                SizedBox(height: 16),
                Text(
                  'Oyun yükleniyor...',
                  style: TextStyle(
                    color: Color(0xFF6C6FA4),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFE8E0FF), Color(0xFFF5F3FF)],
          ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              Column(
                children: [
                  _buildHeader(),
                  _buildScoreBar(),
                  _buildWordCard(),
                  _buildTurnStatusBanner(),
                  if (_showFeedback) _buildFeedbackBanner(),
                  const SizedBox(height: 8),
                  Expanded(
                    child: _isFrozen 
                        ? _buildFreezeOverlay() 
                        : _isMyTurn 
                            ? _buildSelectionArea()
                            : _buildWaitingOverlay(),
                  ),
                  if (_selectedSongId != null && _selectedArtist != null && _isMyTurn && !_isFrozen)
                    _buildConfirmButton(),
                ],
              ),
              // Bonus toast overlay
              if (_showBonusToast)
                _buildBonusToast(),
              // Comeback bonus indicator in header
              if (_room?.comeback != null && 
                  _room!.comeback!.activeForUid == _myUid && 
                  _room!.comeback!.isActive)
                _buildComebackIndicator(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    if (_myUid == null || _room == null) return const SizedBox.shrink();

    final isTimeRace = _room!.modeVariant == ModeVariant.timeRace;
    final isUrgent = isTimeRace && _remainingSeconds <= 60;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _showExitDialog(),
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha:0.9),
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha:0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.close, size: 20, color: Color(0xFF394272)),
            ),
          ),
          const Spacer(),

          // Mode badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _getModeColor().withValues(alpha:0.15),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(_getModeEmoji(), style: const TextStyle(fontSize: 12)),
                const SizedBox(width: 4),
                Text(
                  _getModeName(),
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: _getModeColor(),
                  ),
                ),
              ],
            ),
          ),

          const Spacer(),

          // Timer
          if (isTimeRace)
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Transform.scale(
                  scale: isUrgent ? _pulseAnimation.value : 1.0,
                  child: child,
                );
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  gradient: isUrgent
                      ? const LinearGradient(colors: [Color(0xFFF85149), Color(0xFFFF7B6B)])
                      : null,
                  color: isUrgent ? null : const Color(0xFFF85149).withValues(alpha:0.15),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.timer_rounded,
                      size: 18,
                      color: isUrgent ? Colors.white : const Color(0xFFF85149),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _formatTime(_remainingSeconds),
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w800,
                        color: isUrgent ? Colors.white : const Color(0xFFF85149),
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildScoreBar() {
    if (_myUid == null || _room == null) return const SizedBox.shrink();

    final myPlayer = _room!.players[_myUid];
    final opponentUid = _room!.players.keys.firstWhere((uid) => uid != _myUid, orElse: () => '');
    final opponentPlayer = opponentUid.isNotEmpty ? _room!.players[opponentUid] : null;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.95),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha:0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // My score
          Expanded(
            child: _buildPlayerScoreCard(
              name: 'Sen',
              score: myPlayer?.score ?? 0,
              solved: myPlayer?.solvedCount ?? 0,
              isActive: _isMyTurn,
              isMe: true,
              showPop: _showMyScorePop,
            ),
          ),
          
          // VS divider
          Container(
            margin: const EdgeInsets.symmetric(horizontal: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFFF5F3FF),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Text(
              'VS',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: Color(0xFF6C6FA4),
              ),
            ),
          ),
          
          // Opponent score
          Expanded(
            child: _buildPlayerScoreCard(
              name: opponentPlayer?.name ?? 'Rakip',
              score: opponentPlayer?.score ?? 0,
              solved: opponentPlayer?.solvedCount ?? 0,
              isActive: !_isMyTurn,
              isMe: false,
              showPop: _showOpponentScorePop,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerScoreCard({
    required String name,
    required int score,
    required int solved,
    required bool isActive,
    required bool isMe,
    required bool showPop,
  }) {
    final activeColor = isMe ? const Color(0xFFCAB7FF) : const Color(0xFFFFB958);

    return AnimatedBuilder(
      animation: _turnChangeAnimation,
      builder: (context, child) {
        return AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            gradient: isActive
                ? LinearGradient(
                    colors: [activeColor.withValues(alpha:0.2), activeColor.withValues(alpha:0.1)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  )
                : null,
            borderRadius: BorderRadius.circular(14),
            border: isActive
                ? Border.all(color: activeColor, width: 2)
                : Border.all(color: Colors.grey.shade200),
          ),
          child: child,
        );
      },
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (isActive)
                Container(
                  width: 8,
                  height: 8,
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    color: isMe ? const Color(0xFFCAB7FF) : const Color(0xFFFFB958),
                    shape: BoxShape.circle,
                  ),
                ),
              Flexible(
                child: Text(
                  name,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                    color: isActive ? const Color(0xFF394272) : const Color(0xFF6C6FA4),
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          AnimatedBuilder(
            animation: _scorePopAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: showPop ? _scorePopAnimation.value : 1.0,
                child: child,
              );
            },
            child: Text(
              '$score',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w900,
                color: isMe ? const Color(0xFF394272) : const Color(0xFFFFB958),
              ),
            ),
          ),
          Text(
            'Çözülen: $solved',
            style: TextStyle(
              fontSize: 10,
              color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWordCard() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _isMyTurn ? _pulseAnimation.value : 1.0,
          child: child,
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_getModeColor(), _getModeColor().withValues(alpha:0.7)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: _getModeColor().withValues(alpha:0.35),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha:0.25),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                '🎯 KELİME',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              (_room?.currentWord ?? '').toUpperCase(),
              style: const TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 3,
                shadows: [
                  Shadow(
                    color: Colors.black26,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTurnStatusBanner() {
    return AnimatedBuilder(
      animation: _turnChangeAnimation,
      builder: (context, child) {
        return AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _isMyTurn ? _buildMyTurnBanner() : _buildOpponentTurnBanner(),
        );
      },
    );
  }

  Widget _buildMyTurnBanner() {
    return Container(
      key: const ValueKey('my-turn'),
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFCAB7FF), Color(0xFF9B7EDE)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFCAB7FF).withValues(alpha:0.3),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha:0.25),
              shape: BoxShape.circle,
            ),
            child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'SENİN SIRAIN',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: 1,
                ),
              ),
              Text(
                'Sanatçı ve şarkı seç',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOpponentTurnBanner() {
    final opponentUid = _room?.players.keys.firstWhere((uid) => uid != _myUid, orElse: () => '');
    final opponentName = opponentUid != null && opponentUid.isNotEmpty 
        ? _room?.players[opponentUid]?.name ?? 'Rakip' 
        : 'Rakip';

    return Container(
      key: const ValueKey('opponent-turn'),
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0xFFFFB958).withValues(alpha:0.15),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFB958).withValues(alpha:0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 24,
            height: 24,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: const Color(0xFFFFB958),
            ),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'RAKİP OYNUYOR',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFFFFB958),
                  letterSpacing: 0.5,
                ),
              ),
              Text(
                '$opponentName düşünüyor...',
                style: TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFeedbackBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: _feedbackColor?.withValues(alpha:0.15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _feedbackColor?.withValues(alpha:0.3) ?? Colors.grey),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _feedbackMessage ?? '',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: _feedbackColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWaitingOverlay() {
    return Container(
      margin: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.7),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Stack(
        children: [
          // Dimmed selection area
          Opacity(
            opacity: 0.3,
            child: IgnorePointer(
              child: _buildSelectionArea(),
            ),
          ),
          // Lock overlay
          Center(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha:0.95),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha:0.1),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Stack(
                    alignment: Alignment.center,
                    children: [
                      // Animated ring
                      AnimatedBuilder(
                        animation: _pulseAnimation,
                        builder: (context, child) {
                          return Container(
                            width: 80 * _pulseAnimation.value,
                            height: 80 * _pulseAnimation.value,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: const Color(0xFFFFB958).withValues(alpha:0.3),
                                width: 2,
                              ),
                            ),
                          );
                        },
                      ),
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFFB958), Color(0xFFFFCE54)],
                          ),
                          shape: BoxShape.circle,
                        ),
                        child: const Center(
                          child: Icon(Icons.hourglass_top_rounded, color: Colors.white, size: 30),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Sıra Rakipte',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF394272),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Bekle, sonra senin sıran',
                    style: TextStyle(
                      fontSize: 13,
                      color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFreezeOverlay() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(40),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha:0.95),
          borderRadius: BorderRadius.circular(32),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFF85149).withValues(alpha:0.2),
              blurRadius: 24,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFF85149), Color(0xFFFF7B6B)],
                ),
                shape: BoxShape.circle,
              ),
              child: const Center(
                child: Text('🥶', style: TextStyle(fontSize: 40)),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'DONDURULDU',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: Color(0xFFF85149),
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$_freezeSeconds saniye',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF6C6FA4),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: 100,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: _room?.modeVariant == ModeVariant.timeRace 
                      ? (1 - _freezeSeconds / 3) 
                      : (1 - _freezeSeconds / 1),
                  backgroundColor: const Color(0xFFE0E0E0),
                  valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFF85149)),
                  minHeight: 6,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionArea() {
    final availableSongs = _songs
        .map((s) => SongItem(
              id: s.id,
              artist: s.artist,
              title: s.title,
            ))
        .toList();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DualColumnSelector(
        artists: _artists,
        songs: availableSongs,
        selectedArtist: _selectedArtist,
        selectedSongId: _selectedSongId,
        onArtistSelected: (artist) {
          if (_isMyTurn && !_isFrozen) {
            setState(() {
              _selectedArtist = artist;
              _selectedSongId = null;
            });
            HapticService.selection();
          }
        },
        onSongSelected: (songId) {
          if (_isMyTurn && !_isFrozen) {
            setState(() => _selectedSongId = songId);
            HapticService.selection();
          }
        },
        disabled: !_isMyTurn || _isFrozen || _isSubmitting,
      ),
    );
  }

  Widget _buildConfirmButton() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Container(
        width: double.infinity,
        height: 58,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_getModeColor(), _getModeColor().withValues(alpha:0.8)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: _getModeColor().withValues(alpha:0.4),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: _isSubmitting ? null : _submitSelection,
            child: Center(
              child: _isSubmitting
                  ? const SizedBox(
                      width: 24,
                      height: 24,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.check_rounded, color: Colors.white, size: 24),
                        SizedBox(width: 10),
                        Text(
                          'ONAYLA',
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  void _showExitDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            const Text('🚪', style: TextStyle(fontSize: 24)),
            const SizedBox(width: 10),
            const Text('Oyundan Çık'),
          ],
        ),
        content: const Text('Oyundan çıkarsan maçı kaybedersin.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Devam Et'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            style: TextButton.styleFrom(foregroundColor: const Color(0xFFF85149)),
            child: const Text('Çık'),
          ),
        ],
      ),
    );
  }

  Color _getModeColor() {
    switch (_room?.modeVariant) {
      case ModeVariant.timeRace:
        return const Color(0xFFFF6B6B);
      case ModeVariant.relax:
        return const Color(0xFF66BB6A);
      case ModeVariant.real:
        return const Color(0xFFFFB958);
      default:
        return const Color(0xFFCAB7FF);
    }
  }

  String _getModeEmoji() {
    switch (_room?.modeVariant) {
      case ModeVariant.timeRace:
        return '⚡';
      case ModeVariant.relax:
        return '🧘';
      case ModeVariant.real:
        return '⚔️';
      default:
        return '🎮';
    }
  }

  String _getModeName() {
    switch (_room?.modeVariant) {
      case ModeVariant.timeRace:
        return 'TIME RACE';
      case ModeVariant.relax:
        return 'RELAX';
      case ModeVariant.real:
        return 'REAL';
      default:
        return 'ONLINE';
    }
  }

  Widget _buildBonusToast() {
    return Positioned(
      top: 100,
      left: 20,
      right: 20,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: 1.0),
        duration: const Duration(milliseconds: 400),
        curve: Curves.elasticOut,
        builder: (context, value, child) {
          return Transform.scale(
            scale: value,
            child: child,
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _bonusToastColor ?? const Color(0xFFFFB958),
                (_bonusToastColor ?? const Color(0xFFFFB958)).withValues(alpha:0.8),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: (_bonusToastColor ?? const Color(0xFFFFB958)).withValues(alpha:0.4),
                blurRadius: 16,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                _bonusToastIcon ?? Icons.star,
                color: Colors.white,
                size: 28,
              ),
              const SizedBox(width: 12),
              Flexible(
                child: Text(
                  _bonusToastMessage ?? '',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildComebackIndicator() {
    final multiplier = _room?.comeback?.multiplier ?? 1;
    
    return Positioned(
      top: 60,
      right: 16,
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.8, end: 1.0),
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
        builder: (context, value, child) {
          return Transform.scale(
            scale: value,
            child: child,
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFF6B6B), Color(0xFFFFB958)],
            ),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF6B6B).withValues(alpha:0.4),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.local_fire_department, size: 18, color: Colors.white),
              const SizedBox(width: 6),
              Text(
                'x$multiplier',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 4),
              const Text(
                'BONUS',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: Colors.white70,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
