import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../../models/challenge_model.dart';
import '../../models/word_set_model.dart';
import '../../services/challenge_service.dart';
import '../../services/haptic_service.dart';
import '../../widgets/challenge_ui_components.dart';
import '../../game_engine/game_mode.dart';
import 'challenge_result_screen.dart';

/// Challenge Game Screen - Premium UI Refactor
/// 
/// Features:
/// - Soft cloudy background with glass cards
/// - Searchable bottom sheet pickers (not long column lists)
/// - Always visible "Bulduğun Şarkılar" section
/// - Consistent header with mode pill + timer pill
/// - Freeze overlay for wrong answers
class ChallengeGameScreen extends StatefulWidget {
  final ChallengeModel challenge;
  final ChallengePlayMode playMode;
  final ChallengeSingleMode singleMode;

  const ChallengeGameScreen({
    super.key,
    required this.challenge,
    this.playMode = ChallengePlayMode.solo,
    this.singleMode = ChallengeSingleMode.relax,
  });

  @override
  State<ChallengeGameScreen> createState() => _ChallengeGameScreenState();
}

class _ChallengeGameScreenState extends State<ChallengeGameScreen>
    with TickerProviderStateMixin {
  final ChallengeService _challengeService = ChallengeService();
  final Random _random = Random();

  // Game state
  List<ChallengeSongModel> _allSongs = [];
  List<ChallengeSongModel> _remainingSongs = [];
  final List<ChallengeSongModel> _solvedSongs = [];
  final Set<String> _solvedSongIds = {};

  String _currentWord = '';
  List<ChallengeSongModel> _validSongsForWord = [];

  // Selection state
  String? _selectedArtist;
  ChallengeSongModel? _selectedSong;
  List<String> _artistList = [];
  List<ChallengeSongModel> _songsForSelectedArtist = [];

  // Timing
  int _totalSeconds = 0;
  int _roundSeconds = 30;
  int _freezeSeconds = 0;
  int _totalFreezeTime = 3;
  Timer? _timer;

  // Scoring (Real mode)
  int _score = 0;
  int _correctCount = 0;
  int _wrongCount = 0;

  // Relax mode progressive freeze
  int _consecutiveWrong = 0;
  int _currentFreezeTime = 1;

  // UI state
  bool _isLoading = true;
  bool _isFinished = false;
  bool _isFrozen = false;
  bool _isSubmitting = false;

  // Feedback state
  String? _feedbackMessage;
  bool? _feedbackIsCorrect;
  String? _feedbackBonus;
  bool _showFeedback = false;

  // Mode settings
  int get _totalTimeLimit => 5 * 60; // 5 minutes for Time Race
  int get _roundTimeLimit => 30;

  @override
  void initState() {
    super.initState();
    _loadSongs();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadSongs() async {
    try {
      final songs = await _challengeService.getSongsForChallenge(widget.challenge.id);
      
      if (!mounted) return;
      
      setState(() {
        _allSongs = songs;
        _remainingSongs = List.from(songs);
        _isLoading = false;
      });

      _selectNextWord();
      _startTimer();
      HapticService.gameStart();
    } catch (e) {
      debugPrint('Error loading songs: $e');
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _selectNextWord() {
    if (_remainingSongs.isEmpty) {
      _finishGame();
      return;
    }

    // Get available words from topKeywords
    final availableWords = <String>{};
    for (final song in _remainingSongs) {
      if (song.topKeywords.isNotEmpty) {
        availableWords.addAll(song.topKeywords);
      } else if (song.keywords.isNotEmpty) {
        availableWords.addAll(song.keywords);
      }
    }

    if (availableWords.isEmpty) {
      _finishGame();
      return;
    }

    // Random word selection
    final wordList = availableWords.toList();
    final word = wordList[_random.nextInt(wordList.length)];

    // Find valid songs for this word
    final validSongs = _remainingSongs.where((song) {
      return song.containsWord(word) && !_solvedSongIds.contains(song.id);
    }).toList();

    if (validSongs.isEmpty) {
      // Try again with different word
      if (wordList.length > 1) {
        _selectNextWord();
        return;
      }
      _finishGame();
      return;
    }

    // Get unique artists for this word
    final artistSet = validSongs.map((s) => s.artist).toSet().toList()..sort();

    setState(() {
      _currentWord = word;
      _validSongsForWord = validSongs;
      _artistList = artistSet;
      _selectedArtist = null;
      _selectedSong = null;
      _songsForSelectedArtist = [];
      _roundSeconds = _roundTimeLimit;
    });
  }

  void _startTimer() {
    _timer?.cancel();
    
    _totalSeconds = widget.singleMode == ChallengeSingleMode.timeRace 
        ? _totalTimeLimit 
        : 0;
    
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted || _isFinished) return;

      setState(() {
        // Handle freeze
        if (_isFrozen) {
          if (_freezeSeconds > 0) {
            _freezeSeconds--;
          } else {
            _isFrozen = false;
            HapticService.freezeEnd();
          }
          return;
        }

        // Time Race mode: global countdown
        if (widget.singleMode == ChallengeSingleMode.timeRace) {
          if (_totalSeconds > 0) {
            _totalSeconds--;
            
            // Haptic warnings
            if (_totalSeconds <= 30 && _totalSeconds % 10 == 0) {
              HapticService.timeWarning();
            }
            if (_totalSeconds <= 5) {
              HapticService.timeCritical();
            }
          } else {
            HapticService.timeExpired();
            _finishGame();
          }
        }
        
        // Round timer for Relax and Real modes
        if (widget.singleMode != ChallengeSingleMode.timeRace) {
          if (_roundSeconds > 0) {
            _roundSeconds--;
            
            if (_roundSeconds <= 5) {
              HapticService.timeCritical();
            }
          } else {
            // Time expired for this word - move to next
            _selectNextWord();
          }
        }
      });
    });
  }

  void _onArtistSelected(String artist) {
    // Get songs for this artist that are valid for current word
    final songs = _validSongsForWord.where((s) => s.artist == artist).toList();
    
    setState(() {
      _selectedArtist = artist;
      _selectedSong = null;
      _songsForSelectedArtist = songs;
    });
  }

  void _onSongSelected(ChallengeSongModel song) {
    setState(() {
      _selectedSong = song;
    });
  }

  void _onSubmit() {
    if (_selectedArtist == null || _selectedSong == null || _isFrozen || _isSubmitting) return;

    setState(() => _isSubmitting = true);

    // Check if selection is correct
    final isCorrect = _validSongsForWord.any((s) => s.id == _selectedSong!.id);

    if (isCorrect) {
      _handleCorrectAnswer();
    } else {
      _handleWrongAnswer();
    }

    setState(() => _isSubmitting = false);
  }

  void _handleCorrectAnswer() {
    HapticService.correct();
    _consecutiveWrong = 0;
    _currentFreezeTime = 1;

    // Scoring based on mode
    int points = 1;
    String? bonus;

    switch (widget.singleMode) {
      case ChallengeSingleMode.timeRace:
        // Speed bonus: more points for faster answers
        if (_roundSeconds >= 25) {
          points = 3;
          bonus = 'Hızlı! +3';
        } else if (_roundSeconds >= 15) {
          points = 2;
          bonus = '+2';
        }
        break;
      case ChallengeSingleMode.relax:
        points = 1;
        break;
      case ChallengeSingleMode.real:
        points = 1;
        break;
    }

    setState(() {
      _score += points;
      _correctCount++;
      _solvedSongs.add(_selectedSong!);
      _solvedSongIds.add(_selectedSong!.id);
      _remainingSongs.removeWhere((s) => s.id == _selectedSong!.id);
      
      _feedbackMessage = 'Doğru! 🎉';
      _feedbackIsCorrect = true;
      _feedbackBonus = bonus;
      _showFeedback = true;
    });

    // Hide feedback and move to next word
    Future.delayed(const Duration(milliseconds: 1200), () {
      if (mounted) {
        setState(() => _showFeedback = false);
        _selectNextWord();
      }
    });
  }

  void _handleWrongAnswer() {
    HapticService.wrong();
    _consecutiveWrong++;

    // Scoring and freeze based on mode
    int freezeTime = 0;
    int penalty = 0;

    switch (widget.singleMode) {
      case ChallengeSingleMode.timeRace:
        freezeTime = 3;
        break;
      case ChallengeSingleMode.relax:
        // Progressive freeze: 1s, 2s, 3s, 4s...
        freezeTime = _currentFreezeTime;
        _currentFreezeTime = (_currentFreezeTime + 1).clamp(1, 5);
        break;
      case ChallengeSingleMode.real:
        penalty = 3;
        break;
    }

    setState(() {
      _score -= penalty;
      _wrongCount++;
      
      if (freezeTime > 0) {
        _isFrozen = true;
        _freezeSeconds = freezeTime;
        _totalFreezeTime = freezeTime;
        HapticService.freezeStart();
      }
      
      _feedbackMessage = 'Yanlış! ❌';
      _feedbackIsCorrect = false;
      _feedbackBonus = penalty > 0 ? '-$penalty puan' : null;
      _showFeedback = true;
    });

    // Clear selection
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        setState(() {
          _showFeedback = false;
          _selectedArtist = null;
          _selectedSong = null;
          _songsForSelectedArtist = [];
        });
      }
    });
  }

  void _finishGame() {
    if (_isFinished) return;

    _timer?.cancel();
    setState(() => _isFinished = true);

    HapticService.challengeComplete();

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ChallengeResultScreen(
          challenge: widget.challenge,
          mode: widget.singleMode,
          solvedSongs: _solvedSongs,
          totalSongs: _allSongs.length,
          score: _score,
          correctCount: _correctCount,
          wrongCount: _wrongCount,
          durationSeconds: widget.singleMode == ChallengeSingleMode.timeRace 
              ? _totalTimeLimit - _totalSeconds 
              : _totalSeconds,
          timedOut: widget.singleMode == ChallengeSingleMode.timeRace && _totalSeconds <= 0,
        ),
      ),
    );
  }

  void _showExitDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Oyundan Çık'),
        content: const Text('İlerlemeniz kaydedilmeyecek. Çıkmak istediğinize emin misiniz?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('İptal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Çık', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _openArtistPicker() {
    if (_isFrozen) return;

    SearchableBottomSheetPicker.show<String>(
      context: context,
      title: 'Sanatçı Seç',
      items: _artistList,
      itemLabel: (artist) => artist,
      selectedItem: _selectedArtist,
      searchHint: 'Sanatçı ara...',
      accentColor: ChallengeColors.primaryPurple,
      onSelect: _onArtistSelected,
    );
  }

  void _openSongPicker() {
    if (_isFrozen || _selectedArtist == null) return;

    SearchableBottomSheetPicker.show<ChallengeSongModel>(
      context: context,
      title: 'Şarkı Seç',
      items: _songsForSelectedArtist,
      itemLabel: (song) => song.title,
      itemSubtitle: (song) => song.artist,
      selectedItem: _selectedSong,
      searchHint: 'Şarkı ara...',
      accentColor: ChallengeColors.primaryPurple,
      onSelect: _onSongSelected,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return _buildLoadingScreen();
    }

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background
          _buildBackground(),

          // Main content
          SafeArea(
            child: Column(
              children: [
                // Header - Just back button
                _buildHeader(),

                // Scrollable content
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                    child: Column(
                      children: [
                        const SizedBox(height: 16),

                        // HERO WORD - Glowing card with ring
                        Center(
                          child: WordHeroCard(
                            word: _currentWord,
                            categoryName: widget.challenge.title,
                          ),
                        ),

                        const SizedBox(height: 24),

                        // Selection card with yan yana pickers + Onayla
                        SelectionInputCard(
                          selectedArtist: _selectedArtist,
                          selectedSong: _selectedSong?.title,
                          enabled: !_isFrozen,
                          onArtistTap: _openArtistPicker,
                          onSongTap: _openSongPicker,
                          onSubmit: _onSubmit,
                          isSubmitting: _isSubmitting,
                        ),

                        const SizedBox(height: 16),

                        // Solved songs - white card
                        SolvedSongsCard(
                          songs: _solvedSongs,
                          maxVisible: 4,
                        ),

                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),

                // Bottom stats bar
                _buildBottomStats(),
              ],
            ),
          ),

          // Freeze overlay
          if (_isFrozen)
            Positioned.fill(
              child: ChallengeFreezeOverlay(
                secondsLeft: _freezeSeconds,
                totalSeconds: _totalFreezeTime,
              ),
            ),

          // Feedback toast
          if (_showFeedback && _feedbackMessage != null)
            Positioned(
              top: MediaQuery.of(context).padding.top + 100,
              left: 40,
              right: 40,
              child: Center(
                child: ChallengeFeedbackToast(
                  message: _feedbackMessage!,
                  isCorrect: _feedbackIsCorrect ?? false,
                  bonus: _feedbackBonus,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBackground() {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Base image
        Image.asset(
          'assets/images/bg_music_clouds.png',
          fit: BoxFit.cover,
        ),
        // Soft overlay
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Colors.white.withOpacity(0.25),
                Colors.white.withOpacity(0.1),
                ChallengeColors.softPurple.withOpacity(0.3),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildLoadingScreen() {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          _buildBackground(),
          Center(
            child: GlassCard(
              padding: const EdgeInsets.all(40),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    color: ChallengeColors.primaryPurple,
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    'Şarkılar yükleniyor...',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: ChallengeColors.darkPurple,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    // Timer hesaplamaları
    final currentTime = widget.singleMode == ChallengeSingleMode.timeRace
        ? _totalSeconds
        : _roundSeconds;
    final maxTime = widget.singleMode == ChallengeSingleMode.timeRace
        ? _totalTimeLimit
        : _roundTimeLimit;
    final progress = currentTime / maxTime;
    final isUrgent = progress <= 0.2; // Son %20
    final isCritical = progress <= 0.1; // Son %10

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // Sol: Back button + Progress Slots
          Row(
            children: [
              // Back button
              GestureDetector(
                onTap: _showExitDialog,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.9),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 8,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.arrow_back_rounded,
                    color: Color(0xFF394272),
                    size: 20,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              // Progress Slots
              _buildProgressSlots(),
            ],
          ),

          const Spacer(),

          // Sağ: Dairesel Timer
          _buildCircularTimer(
            currentTime: currentTime,
            maxTime: maxTime,
            isUrgent: isUrgent,
            isCritical: isCritical,
          ),
        ],
      ),
    );
  }

  /// Progress slot'ları - tamamlanan şarkılar için check işaretli yuvarlaklar
  Widget _buildProgressSlots() {
    final totalSlots = _allSongs.length.clamp(0, 8); // Max 8 slot göster
    final solvedCount = _solvedSongs.length;

    if (totalSlots == 0) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: List.generate(totalSlots, (index) {
          final isFilled = index < solvedCount;
          final isNext = index == solvedCount;

          return Padding(
            padding: EdgeInsets.only(left: index > 0 ? 6 : 0),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              curve: Curves.easeOutBack,
              width: isNext ? 22 : 18,
              height: isNext ? 22 : 18,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isFilled
                    ? const Color(0xFF4CAF50)
                    : isNext
                        ? const Color(0xFFCAB7FF).withValues(alpha: 0.3)
                        : Colors.grey.withValues(alpha: 0.2),
                border: isNext
                    ? Border.all(
                        color: const Color(0xFFCAB7FF),
                        width: 2,
                      )
                    : null,
                boxShadow: isFilled ? [
                  BoxShadow(
                    color: const Color(0xFF4CAF50).withValues(alpha: 0.4),
                    blurRadius: 6,
                    offset: const Offset(0, 2),
                  ),
                ] : null,
              ),
              child: isFilled
                  ? const Icon(
                      Icons.check_rounded,
                      size: 12,
                      color: Colors.white,
                    )
                  : null,
            ),
          );
        }),
      ),
    );
  }

  /// Dairesel timer - pulsing efekti ile
  Widget _buildCircularTimer({
    required int currentTime,
    required int maxTime,
    required bool isUrgent,
    required bool isCritical,
  }) {
    final progress = currentTime / maxTime;

    // Renk geçişi
    Color timerColor;
    if (isCritical) {
      timerColor = const Color(0xFFE53935); // Kırmızı
    } else if (isUrgent) {
      timerColor = const Color(0xFFFF6B6B); // Açık kırmızı
    } else if (progress <= 0.4) {
      timerColor = const Color(0xFFFF8C42); // Turuncu
    } else {
      timerColor = const Color(0xFF4CAF50); // Yeşil
    }

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 1.0, end: isCritical ? 1.08 : 1.0),
      duration: Duration(milliseconds: isCritical ? 500 : 300),
      curve: Curves.easeInOut,
      builder: (context, scale, child) {
        return Transform.scale(
          scale: scale,
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                  color: timerColor.withValues(alpha: isUrgent ? 0.4 : 0.2),
                  blurRadius: isUrgent ? 16 : 10,
                  spreadRadius: isUrgent ? 2 : 0,
                ),
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Dairesel ilerleme çubuğu
                SizedBox(
                  width: 52,
                  height: 52,
                  child: CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 4,
                    backgroundColor: Colors.grey.withValues(alpha: 0.15),
                    valueColor: AlwaysStoppedAnimation<Color>(timerColor),
                    strokeCap: StrokeCap.round,
                  ),
                ),
                // Süre yazısı
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      '${currentTime ~/ 60}:${(currentTime % 60).toString().padLeft(2, '0')}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w900,
                        color: timerColor,
                        height: 1,
                      ),
                    ),
                    if (widget.singleMode == ChallengeSingleMode.timeRace)
                      Text(
                        'KALAN',
                        style: TextStyle(
                          fontSize: 7,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey.shade500,
                          letterSpacing: 0.5,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBottomStats() {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color(0xFFFFFFFE),
            Color(0xFFF8F0FF),
            Color(0xFFE8F4F8),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withValues(alpha: 0.6),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          // Mode
          _buildStatItem(
            emoji: _getModeEmoji(),
            label: _getModeName(),
            color: _getModeColor(),
          ),

          Container(
            width: 1,
            height: 40,
            color: Colors.grey.shade200,
          ),

          // Çözülen
          _buildStatItem(
            emoji: '✓',
            label: 'Çözülen',
            value: '${_solvedSongs.length}',
            color: const Color(0xFF4CAF50),
          ),

          Container(
            width: 1,
            height: 40,
            color: Colors.grey.shade200,
          ),

          // Kalan
          _buildStatItem(
            emoji: '○',
            label: 'Kalan',
            value: '${_allSongs.length - _solvedSongs.length}',
            color: const Color(0xFF394272),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({
    required String emoji,
    required String label,
    String? value,
    required Color color,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          emoji,
          style: const TextStyle(fontSize: 18),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: Colors.grey.shade600,
            fontWeight: FontWeight.w500,
          ),
        ),
        if (value != null) ...[
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
        ],
      ],
    );
  }

  String _getModeEmoji() {
    switch (widget.singleMode) {
      case ChallengeSingleMode.timeRace:
        return '⚡';
      case ChallengeSingleMode.relax:
        return '🧘';
      case ChallengeSingleMode.real:
        return '🏆';
    }
  }

  Color _getModeColor() {
    switch (widget.singleMode) {
      case ChallengeSingleMode.timeRace:
        return const Color(0xFFFF6B6B);
      case ChallengeSingleMode.relax:
        return const Color(0xFF66BB6A);
      case ChallengeSingleMode.real:
        return const Color(0xFFFFB958);
    }
  }
  
  String _getModeName() {
    switch (widget.singleMode) {
      case ChallengeSingleMode.timeRace:
        return 'Time Race';
      case ChallengeSingleMode.relax:
        return 'Relax';
      case ChallengeSingleMode.real:
        return 'Real';
    }
  }
}
