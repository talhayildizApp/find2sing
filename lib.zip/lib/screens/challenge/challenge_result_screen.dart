import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../models/challenge_model.dart';
import '../../services/leaderboard_service.dart';
import 'challenge_mode_select_screen.dart';
import 'challenge_detail_screen.dart';
import 'leaderboard_screen.dart';

/// Challenge Result Screen with celebration UX
/// - Mini achievement scene on completion
/// - Stats summary (time, correct/wrong, score)
/// - Leaderboard feedback for Real Challenge
/// - "Bunu bitirdim" feeling
class ChallengeResultScreen extends StatefulWidget {
  final ChallengeModel challenge;
  final ChallengeSingleMode mode;
  final List<ChallengeSongModel> solvedSongs;
  final int totalSongs;
  final int score;
  final int correctCount;
  final int wrongCount;
  final int durationSeconds;
  final bool timedOut;
  final bool isOnline;
  final String? opponentName;
  final int? opponentScore;

  const ChallengeResultScreen({
    super.key,
    required this.challenge,
    required this.mode,
    required this.solvedSongs,
    required this.totalSongs,
    this.score = 0,
    this.correctCount = 0,
    this.wrongCount = 0,
    required this.durationSeconds,
    this.timedOut = false,
    this.isOnline = false,
    this.opponentName,
    this.opponentScore,
  });

  @override
  State<ChallengeResultScreen> createState() => _ChallengeResultScreenState();
}

class _ChallengeResultScreenState extends State<ChallengeResultScreen>
    with TickerProviderStateMixin {
  late AnimationController _celebrationController;
  late AnimationController _statsController;
  late AnimationController _leaderboardController;
  
  late Animation<double> _celebrationScale;
  late Animation<double> _statsSlide;
  late Animation<double> _leaderboardFade;

  bool _leaderboardSaved = false;
  bool _savingLeaderboard = false;
  int? _leaderboardRank;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _playEntryAnimation();
    
    // Save to leaderboard for Single Real Challenge only
    if (widget.mode == ChallengeSingleMode.real && !widget.isOnline) {
      _saveToLeaderboard();
    }
  }

  void _initAnimations() {
    _celebrationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _celebrationScale = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _celebrationController, curve: Curves.elasticOut),
    );

    _statsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _statsSlide = Tween<double>(begin: 50.0, end: 0.0).animate(
      CurvedAnimation(parent: _statsController, curve: Curves.easeOutCubic),
    );

    _leaderboardController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _leaderboardFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _leaderboardController, curve: Curves.easeIn),
    );
  }

  void _playEntryAnimation() async {
    await Future.delayed(const Duration(milliseconds: 200));
    _celebrationController.forward();
    HapticFeedback.mediumImpact();
    
    await Future.delayed(const Duration(milliseconds: 400));
    _statsController.forward();
    
    await Future.delayed(const Duration(milliseconds: 300));
    _leaderboardController.forward();
  }

  Future<void> _saveToLeaderboard() async {
    setState(() => _savingLeaderboard = true);
    
    try {
      final service = LeaderboardService();
      final rank = await service.submitScore(
        challengeId: widget.challenge.id,
        score: widget.score,
        timeSeconds: widget.durationSeconds,
      );
      
      if (mounted) {
        setState(() {
          _leaderboardSaved = true;
          _savingLeaderboard = false;
          _leaderboardRank = rank;
        });
        
        if (rank != null && rank <= 10) {
          HapticFeedback.heavyImpact();
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() => _savingLeaderboard = false);
      }
    }
  }

  @override
  void dispose() {
    _celebrationController.dispose();
    _statsController.dispose();
    _leaderboardController.dispose();
    super.dispose();
  }

  String _formatTime(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }

  String get _modeLabel {
    switch (widget.mode) {
      case ChallengeSingleMode.timeRace:
        return 'Time Race';
      case ChallengeSingleMode.relax:
        return 'Relax';
      case ChallengeSingleMode.real:
        return 'Real Challenge';
    }
  }

  String get _modeEmoji {
    switch (widget.mode) {
      case ChallengeSingleMode.timeRace:
        return '⚡';
      case ChallengeSingleMode.relax:
        return '🧘';
      case ChallengeSingleMode.real:
        return '🏆';
    }
  }

  Color get _modeColor {
    switch (widget.mode) {
      case ChallengeSingleMode.timeRace:
        return const Color(0xFFFF6B6B);
      case ChallengeSingleMode.relax:
        return const Color(0xFF66BB6A);
      case ChallengeSingleMode.real:
        return const Color(0xFFFFB958);
    }
  }

  bool get _isCompleted => widget.solvedSongs.length == widget.totalSongs && !widget.timedOut;
  bool get _isWinner => widget.isOnline && widget.opponentScore != null && widget.score > widget.opponentScore!;
  bool get _isLoser => widget.isOnline && widget.opponentScore != null && widget.score < widget.opponentScore!;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: _isCompleted || _isWinner
                ? [const Color(0xFFE8F5E9), const Color(0xFFF5F3FF)]
                : widget.timedOut || _isLoser
                    ? [const Color(0xFFFFEBEE), const Color(0xFFF5F3FF)]
                    : [const Color(0xFFE8E0FF), const Color(0xFFF5F3FF)],
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 20),
                _buildModeAndOnlineBadge(),
                const SizedBox(height: 24),
                _buildCelebrationSection(),
                const SizedBox(height: 32),
                _buildStatsCard(),
                const SizedBox(height: 20),
                
                // Leaderboard feedback (Single Real Challenge only)
                if (widget.mode == ChallengeSingleMode.real && !widget.isOnline)
                  _buildLeaderboardFeedback(),
                
                // Online disclaimer
                if (widget.isOnline && widget.mode == ChallengeSingleMode.real)
                  _buildOnlineDisclaimer(),
                
                const SizedBox(height: 20),
                
                // Solved songs (collapsible)
                if (widget.solvedSongs.isNotEmpty)
                  _buildSolvedSongsList(),
                
                const SizedBox(height: 32),
                _buildActionButtons(),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildModeAndOnlineBadge() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
          decoration: BoxDecoration(
            color: _modeColor.withOpacity(0.15),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: _modeColor.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(_modeEmoji, style: const TextStyle(fontSize: 14)),
              const SizedBox(width: 6),
              Text(
                _modeLabel,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: _modeColor,
                ),
              ),
            ],
          ),
        ),
        if (widget.isOnline) ...[
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xFF4CAF50).withOpacity(0.15),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                    color: Color(0xFF4CAF50),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                const Text(
                  'ONLINE',
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF4CAF50),
                  ),
                ),
              ],
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildCelebrationSection() {
    return AnimatedBuilder(
      animation: _celebrationScale,
      builder: (context, child) {
        return Transform.scale(
          scale: _celebrationScale.value,
          child: child,
        );
      },
      child: Column(
        children: [
          // Result icon with glow
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: _isCompleted || _isWinner
                    ? [const Color(0xFF4CAF50), const Color(0xFF66BB6A)]
                    : widget.timedOut || _isLoser
                        ? [const Color(0xFFF85149), const Color(0xFFFF7B6B)]
                        : [_modeColor, _modeColor.withOpacity(0.7)],
              ),
              boxShadow: [
                BoxShadow(
                  color: (_isCompleted || _isWinner
                      ? const Color(0xFF4CAF50)
                      : widget.timedOut || _isLoser
                          ? const Color(0xFFF85149)
                          : _modeColor).withOpacity(0.4),
                  blurRadius: 24,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Center(
              child: Text(
                _getResultEmoji(),
                style: const TextStyle(fontSize: 56),
              ),
            ),
          ),
          const SizedBox(height: 24),
          
          // Title
          Text(
            _getResultTitle(),
            style: const TextStyle(
              fontSize: 30,
              fontWeight: FontWeight.w900,
              color: Color(0xFF394272),
            ),
          ),
          const SizedBox(height: 8),
          
          // Subtitle
          Text(
            widget.challenge.title,
            style: TextStyle(
              fontSize: 16,
              color: const Color(0xFF6C6FA4).withOpacity(0.8),
            ),
          ),
          
          // Online opponent score
          if (widget.isOnline && widget.opponentName != null) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Column(
                    children: [
                      const Text('Sen', style: TextStyle(fontSize: 12, color: Color(0xFF6C6FA4))),
                      Text(
                        '${widget.score}',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          color: _isWinner ? const Color(0xFF4CAF50) : const Color(0xFF394272),
                        ),
                      ),
                    ],
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Text(
                      'VS',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: const Color(0xFF6C6FA4).withOpacity(0.5),
                      ),
                    ),
                  ),
                  Column(
                    children: [
                      Text(widget.opponentName!, style: const TextStyle(fontSize: 12, color: Color(0xFF6C6FA4))),
                      Text(
                        '${widget.opponentScore}',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w900,
                          color: _isLoser ? const Color(0xFF4CAF50) : const Color(0xFFFFB958),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _getResultEmoji() {
    if (widget.isOnline) {
      if (_isWinner) return '🏆';
      if (_isLoser) return '😔';
      return '🤝';
    }
    if (_isCompleted) return '🎉';
    if (widget.timedOut) return '⏱️';
    return '💪';
  }

  String _getResultTitle() {
    if (widget.isOnline) {
      if (_isWinner) return 'Kazandın!';
      if (_isLoser) return 'Kaybettin';
      return 'Berabere!';
    }
    if (_isCompleted) return 'Tamamlandı!';
    if (widget.timedOut) return 'Süre Doldu!';
    return 'İyi Gidiyorsun!';
  }

  Widget _buildStatsCard() {
    return AnimatedBuilder(
      animation: _statsSlide,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, _statsSlide.value),
          child: Opacity(
            opacity: 1 - (_statsSlide.value / 50),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            // Progress circle
            SizedBox(
              width: 140,
              height: 140,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  SizedBox(
                    width: 140,
                    height: 140,
                    child: TweenAnimationBuilder<double>(
                      tween: Tween(begin: 0, end: widget.totalSongs > 0 ? widget.solvedSongs.length / widget.totalSongs : 0),
                      duration: const Duration(milliseconds: 1200),
                      curve: Curves.easeOutCubic,
                      builder: (context, value, child) {
                        return CircularProgressIndicator(
                          value: value,
                          strokeWidth: 12,
                          backgroundColor: const Color(0xFFE8E0FF),
                          valueColor: AlwaysStoppedAnimation<Color>(
                            _isCompleted ? const Color(0xFF4CAF50) : _modeColor,
                          ),
                          strokeCap: StrokeCap.round,
                        );
                      },
                    ),
                  ),
                  Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (widget.mode == ChallengeSingleMode.real) ...[
                        TweenAnimationBuilder<int>(
                          tween: IntTween(begin: 0, end: widget.score),
                          duration: const Duration(milliseconds: 1000),
                          builder: (context, value, child) {
                            return Text(
                              '$value',
                              style: TextStyle(
                                fontSize: 36,
                                fontWeight: FontWeight.w900,
                                color: widget.score >= 0 ? const Color(0xFF394272) : const Color(0xFFF85149),
                              ),
                            );
                          },
                        ),
                        const Text(
                          'SKOR',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF6C6FA4),
                            letterSpacing: 1,
                          ),
                        ),
                      ] else ...[
                        Text(
                          '${widget.solvedSongs.length}/${widget.totalSongs}',
                          style: const TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.w900,
                            color: Color(0xFF394272),
                          ),
                        ),
                        const Text(
                          'ŞARKI',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF6C6FA4),
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),
            
            // Stats row
            Row(
              children: [
                Expanded(child: _buildStatItem(
                  icon: Icons.check_circle_rounded,
                  value: '${widget.correctCount}',
                  label: 'Doğru',
                  color: const Color(0xFF4CAF50),
                )),
                Container(
                  width: 1,
                  height: 50,
                  color: const Color(0xFFE0E0E0),
                ),
                Expanded(child: _buildStatItem(
                  icon: Icons.cancel_rounded,
                  value: '${widget.wrongCount}',
                  label: 'Yanlış',
                  color: const Color(0xFFF85149),
                )),
                Container(
                  width: 1,
                  height: 50,
                  color: const Color(0xFFE0E0E0),
                ),
                Expanded(child: _buildStatItem(
                  icon: Icons.timer_rounded,
                  value: _formatTime(widget.durationSeconds),
                  label: 'Süre',
                  color: const Color(0xFF6C6FA4),
                )),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatItem({
    required IconData icon,
    required String value,
    required String label,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 24),
        const SizedBox(height: 8),
        Text(
          value,
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.w800,
            color: color,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF6C6FA4).withOpacity(0.8),
          ),
        ),
      ],
    );
  }

  Widget _buildLeaderboardFeedback() {
    return AnimatedBuilder(
      animation: _leaderboardFade,
      builder: (context, child) {
        return Opacity(
          opacity: _leaderboardFade.value,
          child: child,
        );
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: _leaderboardRank != null && _leaderboardRank! <= 10
              ? const LinearGradient(
                  colors: [Color(0xFFFFB958), Color(0xFFFFCE54)],
                )
              : null,
          color: _leaderboardRank == null ? const Color(0xFFF5F3FF) : null,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _leaderboardRank != null && _leaderboardRank! <= 10
                ? Colors.transparent
                : const Color(0xFFCAB7FF).withOpacity(0.3),
          ),
        ),
        child: Column(
          children: [
            if (_savingLeaderboard) ...[
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFCAB7FF)),
              ),
              const SizedBox(height: 8),
              const Text(
                'Skor kaydediliyor...',
                style: TextStyle(color: Color(0xFF6C6FA4)),
              ),
            ] else if (_leaderboardSaved) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.emoji_events_rounded,
                    color: _leaderboardRank != null && _leaderboardRank! <= 10
                        ? Colors.white
                        : const Color(0xFFFFB958),
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _leaderboardRank != null && _leaderboardRank! <= 10
                            ? 'Top 10\'a Girdin! 🎉'
                            : 'Skor Kaydedildi!',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: _leaderboardRank != null && _leaderboardRank! <= 10
                              ? Colors.white
                              : const Color(0xFF394272),
                        ),
                      ),
                      if (_leaderboardRank != null)
                        Text(
                          'Sıralama: #$_leaderboardRank',
                          style: TextStyle(
                            fontSize: 13,
                            color: _leaderboardRank! <= 10
                                ? Colors.white.withOpacity(0.9)
                                : const Color(0xFF6C6FA4),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => LeaderboardScreen(challenge: widget.challenge),
                      ),
                    );
                  },
                  icon: Icon(
                    Icons.leaderboard_rounded,
                    color: _leaderboardRank != null && _leaderboardRank! <= 10
                        ? Colors.white
                        : const Color(0xFFFFB958),
                  ),
                  label: Text(
                    'Liderlik Tablosu',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: _leaderboardRank != null && _leaderboardRank! <= 10
                          ? Colors.white
                          : const Color(0xFFFFB958),
                    ),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(
                      color: _leaderboardRank != null && _leaderboardRank! <= 10
                          ? Colors.white.withOpacity(0.5)
                          : const Color(0xFFFFB958),
                    ),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildOnlineDisclaimer() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF3E0),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFFB958).withOpacity(0.3)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Color(0xFFFFB958), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Online maçlar liderlik tablosuna kaydedilmez',
              style: TextStyle(
                fontSize: 13,
                color: const Color(0xFF6C6FA4).withOpacity(0.9),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSolvedSongsList() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.music_note_rounded, color: Color(0xFFCAB7FF), size: 22),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Bulduğun Şarkılar',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF394272),
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: const Color(0xFF4CAF50).withOpacity(0.15),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  '${widget.solvedSongs.length}',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF4CAF50),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...widget.solvedSongs.take(8).map((song) => Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: const Color(0xFF4CAF50).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.check_rounded, color: Color(0xFF4CAF50), size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        song.title,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF394272),
                        ),
                      ),
                      Text(
                        song.artist,
                        style: TextStyle(
                          fontSize: 12,
                          color: const Color(0xFF6C6FA4).withOpacity(0.8),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          )),
          if (widget.solvedSongs.length > 8)
            Center(
              child: Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  '+ ${widget.solvedSongs.length - 8} şarkı daha',
                  style: TextStyle(
                    fontSize: 13,
                    color: const Color(0xFF6C6FA4).withOpacity(0.7),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        // Primary CTA
        SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: () {
              if (widget.isOnline) {
                // Rövanş - go back to challenge detail with rematch intent
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChallengeDetailScreen(challenge: widget.challenge),
                  ),
                );
              } else {
                // Tekrar Oyna
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChallengeModeSelectScreen(challenge: widget.challenge),
                  ),
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: _modeColor,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 4,
              shadowColor: _modeColor.withOpacity(0.4),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  widget.isOnline ? Icons.replay_rounded : Icons.play_arrow_rounded,
                  color: Colors.white,
                ),
                const SizedBox(width: 8),
                Text(
                  widget.isOnline ? 'Rövanş' : 'Tekrar Oyna',
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        
        // Secondary CTAs
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 52,
                child: OutlinedButton(
                  onPressed: () {
                    Navigator.of(context).popUntil((route) => route.isFirst);
                  },
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF394272),
                    side: const BorderSide(color: Color(0xFF394272)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: const Text(
                    'Ana Menü',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                ),
              ),
            ),
            if (!widget.isOnline) ...[
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 52,
                  child: OutlinedButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChallengeDetailScreen(challenge: widget.challenge),
                        ),
                      );
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFCAB7FF),
                      side: const BorderSide(color: Color(0xFFCAB7FF)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    child: const Text(
                      'Yeni Challenge',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ],
    );
  }
}
