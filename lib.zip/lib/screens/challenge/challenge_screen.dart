import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/challenge_model.dart';
import '../../models/user_model.dart';
import '../../services/challenge_service.dart';
import '../../services/access_control_service.dart';
import '../auth/login_screen.dart';
import '../auth/profile_screen.dart';
import 'challenge_detail_screen.dart';
import 'category_detail_screen.dart';

class ChallengeScreen extends StatefulWidget {
  const ChallengeScreen({super.key});

  @override
  State<ChallengeScreen> createState() => _ChallengeScreenState();
}

class _ChallengeScreenState extends State<ChallengeScreen> {
  final ChallengeService _challengeService = ChallengeService();
  String _selectedLanguage = 'tr';

  @override
  Widget build(BuildContext context) {
    final authProvider = context.watch<AuthProvider>();
    final user = authProvider.user;
    final isLoggedIn = authProvider.isAuthenticated;

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background - always visible
          Image.asset(
            'assets/images/bg_music_clouds.png',
            fit: BoxFit.cover,
          ),

          SafeArea(
            child: Column(
              children: [
                _buildHeader(context, user, isLoggedIn),
                Expanded(
                  child: !isLoggedIn
                      ? _buildLoginRequired(context)
                      : _buildChallengeContent(context, user),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // HEADER
  // ─────────────────────────────────────────────────────────────────
  Widget _buildHeader(BuildContext context, UserModel? user, bool isLoggedIn) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          // Back button
          _buildCircleButton(
            onTap: () => Navigator.of(context).pop(),
            child: const Icon(
              Icons.arrow_back_ios_new,
              size: 18,
              color: Color(0xFF394272),
            ),
          ),

          const SizedBox(width: 14),

          // Title
          const Expanded(
            child: Text(
              'Challenge',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w800,
                color: Color(0xFF394272),
                letterSpacing: -0.5,
              ),
            ),
          ),

          // Language segmented control
          _buildLanguageSegment(),

          const SizedBox(width: 12),

          // Profile button
          _buildCircleButton(
            onTap: () {
              if (isLoggedIn) {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const ProfileScreen()),
                );
              } else {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                );
              }
            },
            child: user?.photoUrl != null
                ? ClipOval(
                    child: Image.network(
                      user!.photoUrl!,
                      width: 44,
                      height: 44,
                      fit: BoxFit.cover,
                    ),
                  )
                : Icon(
                    isLoggedIn ? Icons.person : Icons.login_rounded,
                    size: 20,
                    color: const Color(0xFF6C6FA4),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCircleButton({required VoidCallback onTap, required Widget child}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha:0.92),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF394272).withValues(alpha:0.08),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(child: child),
      ),
    );
  }

  Widget _buildLanguageSegment() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.85),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF394272).withValues(alpha:0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildLanguageOption('🇹🇷', 'tr'),
          const SizedBox(width: 2),
          _buildLanguageOption('🇬🇧', 'en'),
        ],
      ),
    );
  }

  Widget _buildLanguageOption(String flag, String langCode) {
    final isSelected = _selectedLanguage == langCode;

    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedLanguage = langCode;
        });
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        width: 40,
        height: 36,
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFCAB7FF) : Colors.transparent,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Center(
          child: Text(
            flag,
            style: const TextStyle(fontSize: 20),
          ),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // LOGIN REQUIRED
  // ─────────────────────────────────────────────────────────────────
  Widget _buildLoginRequired(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha:0.9),
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF394272).withValues(alpha:0.1),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 88,
                height: 88,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFCAB7FF), Color(0xFFE8DFFF)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFCAB7FF).withValues(alpha:0.4),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.emoji_events_rounded,
                  size: 44,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 24),
              const Text(
                'Challenge Modu',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF394272),
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Challenge modunu görmek ve\noynamak için giriş yapmalısın.',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 15,
                  color: Color(0xFF6C6FA4),
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const LoginScreen()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCAB7FF),
                    foregroundColor: const Color(0xFF394272),
                    elevation: 0,
                    shadowColor: Colors.transparent,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Giriş Yap',
                    style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // MAIN CONTENT
  // ─────────────────────────────────────────────────────────────────
  Widget _buildChallengeContent(BuildContext context, UserModel? user) {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 12),

          // Categories
          _buildSectionHeader('Kategoriler', showSeeAll: false),
          const SizedBox(height: 14),
          _buildCategoryList(user),

          const SizedBox(height: 28),

          // Popular Challenges
          _buildSectionHeader(
            'Popüler',
            icon: '🔥',
            showSeeAll: true,
            onSeeAllTap: () {
              // TODO: Navigate to all popular challenges
            },
          ),
          const SizedBox(height: 14),
          _buildPopularChallenges(user),

          const SizedBox(height: 28),

          // All Challenges
          _buildSectionHeader(
            "Tüm Challenge'lar",
            icon: '🎵',
            showSeeAll: true,
            onSeeAllTap: () {
              // TODO: Navigate to all challenges
            },
          ),
          const SizedBox(height: 14),
          _buildAllChallenges(user),

          const SizedBox(height: 40),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(
    String title, {
    String? icon,
    bool showSeeAll = false,
    VoidCallback? onSeeAllTap,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            if (icon != null) ...[
              Text(icon, style: const TextStyle(fontSize: 20)),
              const SizedBox(width: 8),
            ],
            Text(
              title,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF394272),
                letterSpacing: -0.3,
              ),
            ),
          ],
        ),
        if (showSeeAll)
          GestureDetector(
            onTap: onSeeAllTap,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha:0.7),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Tümünü Gör',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF6C6FA4),
                    ),
                  ),
                  SizedBox(width: 4),
                  Icon(
                    Icons.arrow_forward_ios,
                    size: 12,
                    color: Color(0xFF6C6FA4),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // CATEGORIES
  // ─────────────────────────────────────────────────────────────────
  Widget _buildCategoryList(UserModel? user) {
    return StreamBuilder<List<CategoryModel>>(
      stream: _challengeService.getCategoriesByLanguage(_selectedLanguage),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: 4,
              itemBuilder: (_, i) => Padding(
                padding: EdgeInsets.only(right: i < 3 ? 12 : 0),
                child: _buildCategorySkeletonCard(),
              ),
            ),
          );
        }

        final categories = snapshot.data!;
        if (categories.isEmpty) {
          return _buildEmptyCard('Kategori bulunamadı');
        }

        return SizedBox(
          height: 130,
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: categories.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: EdgeInsets.only(right: index < categories.length - 1 ? 12 : 0),
                child: _buildCategoryCard(categories[index], user),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildCategorySkeletonCard() {
    return Container(
      width: 130,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.6),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: const Color(0xFFE8E8E8),
              borderRadius: BorderRadius.circular(10),
            ),
          ),
          const Spacer(),
          Container(
            width: 80,
            height: 14,
            decoration: BoxDecoration(
              color: const Color(0xFFE8E8E8),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: 50,
            height: 10,
            decoration: BoxDecoration(
              color: const Color(0xFFE8E8E8),
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryCard(CategoryModel category, UserModel? user) {
    final access = AccessControlService.checkCategoryAccess(user, category);
    final hasAccess = access.hasAccess;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => CategoryDetailScreen(category: category),
          ),
        );
      },
      child: Container(
        width: 130,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: hasAccess
                ? [const Color(0xFFCAB7FF), const Color(0xFFE4DBFF)]
                : [const Color(0xFFE8E8E8), const Color(0xFFF5F5F5)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: hasAccess
                  ? const Color(0xFFCAB7FF).withValues(alpha:0.3)
                  : Colors.black.withValues(alpha:0.05),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  category.iconEmoji ?? '🎵',
                  style: const TextStyle(fontSize: 26),
                ),
                if (!hasAccess)
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha:0.7),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.lock,
                      size: 14,
                      color: Color(0xFF888888),
                    ),
                  ),
              ],
            ),
            const Spacer(),
            Text(
              category.title,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: hasAccess ? const Color(0xFF394272) : const Color(0xFF888888),
                height: 1.2,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '${category.challengeCount} challenge',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: hasAccess ? const Color(0xFF6C6FA4) : const Color(0xFF999999),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // POPULAR CHALLENGES
  // ─────────────────────────────────────────────────────────────────
  Widget _buildPopularChallenges(UserModel? user) {
    return StreamBuilder<List<ChallengeModel>>(
      stream: _challengeService.getPopularChallenges(limit: 5),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return Column(
            children: List.generate(3, (_) => _buildChallengeSkeletonCard()),
          );
        }

        final challenges = snapshot.data!
            .where((c) => c.language == _selectedLanguage)
            .toList();

        if (challenges.isEmpty) {
          return _buildEmptyCard('Bu dilde popüler challenge yok');
        }

        return Column(
          children: challenges.map((c) => _buildChallengeCard(c, user)).toList(),
        );
      },
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // ALL CHALLENGES
  // ─────────────────────────────────────────────────────────────────
  Widget _buildAllChallenges(UserModel? user) {
    return StreamBuilder<List<ChallengeModel>>(
      stream: _challengeService.getChallengesByLanguage(_selectedLanguage),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return Column(
            children: List.generate(4, (_) => _buildChallengeSkeletonCard()),
          );
        }

        final challenges = snapshot.data!;
        if (challenges.isEmpty) {
          return _buildEmptyCard("Challenge'lar yükleniyor...");
        }

        return Column(
          children: challenges.map((c) => _buildChallengeCard(c, user)).toList(),
        );
      },
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // CHALLENGE CARD
  // ─────────────────────────────────────────────────────────────────
  Widget _buildChallengeSkeletonCard() {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.6),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              color: const Color(0xFFE8E8E8),
              borderRadius: BorderRadius.circular(14),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 140,
                  height: 16,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE8E8E8),
                    borderRadius: BorderRadius.circular(4),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Container(
                      width: 60,
                      height: 20,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE8E8E8),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 50,
                      height: 20,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE8E8E8),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChallengeCard(ChallengeModel challenge, UserModel? user) {
    final access = AccessControlService.checkChallengeAccess(user, challenge);
    final hasAccess = access.hasAccess;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChallengeDetailScreen(challenge: challenge),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white.withValues(alpha:0.88),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF394272).withValues(alpha:0.06),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            // Icon container
            Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                gradient: hasAccess
                    ? const LinearGradient(
                        colors: [Color(0xFFE8DFFF), Color(0xFFF5F1FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      )
                    : null,
                color: hasAccess ? null : const Color(0xFFF0F0F0),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: hasAccess
                    ? Text(
                        challenge.type == ChallengeType.artist ? '🎤' : '🎵',
                        style: const TextStyle(fontSize: 24),
                      )
                    : const Icon(
                        Icons.lock_rounded,
                        size: 22,
                        color: Color(0xFF999999),
                      ),
              ),
            ),
            const SizedBox(width: 14),

            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    challenge.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: hasAccess ? const Color(0xFF394272) : const Color(0xFF888888),
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Chips row
                  Wrap(
                    spacing: 6,
                    runSpacing: 4,
                    children: [
                      _buildChip(
                        '${challenge.totalSongs} şarkı',
                        hasAccess: hasAccess,
                      ),
                      _buildChip(
                        challenge.difficultyLabel,
                        hasAccess: hasAccess,
                      ),
                      if (challenge.isFree)
                        _buildChip(
                          'Ücretsiz',
                          hasAccess: true,
                          isHighlight: true,
                        ),
                    ],
                  ),
                ],
              ),
            ),

            // Arrow
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: hasAccess
                    ? const Color(0xFFCAB7FF).withValues(alpha:0.2)
                    : const Color(0xFFF0F0F0),
                shape: BoxShape.circle,
              ),
              child: Icon(
                Icons.chevron_right_rounded,
                size: 20,
                color: hasAccess ? const Color(0xFF6C6FA4) : const Color(0xFFCCCCCC),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChip(String text, {required bool hasAccess, bool isHighlight = false}) {
    Color bgColor;
    Color textColor;

    if (isHighlight) {
      bgColor = const Color(0xFF4CAF50).withValues(alpha:0.12);
      textColor = const Color(0xFF2E7D32);
    } else if (hasAccess) {
      bgColor = const Color(0xFFF5F3FF);
      textColor = const Color(0xFF6C6FA4);
    } else {
      bgColor = const Color(0xFFF0F0F0);
      textColor = const Color(0xFF999999);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────────────────────────
  // EMPTY STATE
  // ─────────────────────────────────────────────────────────────────
  Widget _buildEmptyCard(String message) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withValues(alpha:0.75),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Center(
        child: Text(
          message,
          style: const TextStyle(
            color: Color(0xFF6C6FA4),
            fontSize: 14,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }
}
