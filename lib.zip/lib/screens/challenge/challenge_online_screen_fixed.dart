import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/game_room_model.dart';
import '../../models/match_intent_model.dart';
import '../../models/word_set_model.dart';
import '../../services/challenge_online_service.dart';
import '../../widgets/dual_column_selector.dart';

class ChallengeOnlineScreen extends StatefulWidget {
  final String roomId;

  const ChallengeOnlineScreen({super.key, required this.roomId});

  @override
  State<ChallengeOnlineScreen> createState() => _ChallengeOnlineScreenState();
}

class _ChallengeOnlineScreenState extends State<ChallengeOnlineScreen> {
  final _gameService = ChallengeOnlineService();

  StreamSubscription<GameRoomModel?>? _roomSubscription;
  GameRoomModel? _room;
  List<ChallengeSongWithWords> _songs = [];
  List<String> _artists = [];
  String? _selectedArtist;
  String? _selectedSongId;
  bool _isSubmitting = false;
  bool _isFrozen = false;
  int _freezeSeconds = 0;
  Timer? _freezeTimer;
  Timer? _gameTimer;
  int _remainingSeconds = 0;

  String? get _myUid => context.read<AuthProvider>().user?.uid;
  bool get _isMyTurn => _room?.turnUid == _myUid;

  @override
  void initState() {
    super.initState();
    _listenToRoom();
  }

  @override
  void dispose() {
    _roomSubscription?.cancel();
    _freezeTimer?.cancel();
    _gameTimer?.cancel();
    super.dispose();
  }

  void _listenToRoom() {
    _roomSubscription = _gameService.streamRoom(widget.roomId).listen((room) async {
      if (room == null) return;

      setState(() => _room = room);

      // Load songs if not loaded
      if (_songs.isEmpty && room.challengeId != null) {
        final songs = await _gameService.getChallengeSongs(room.challengeId!);
        final artistSet = songs.map((s) => s.artist).toSet().toList()..sort();
        setState(() {
          _songs = songs;
          _artists = artistSet;
        });
      }

      // Start game timer for time race
      if (room.modeVariant == ModeVariant.timeRace && room.endsAt != null) {
        _startGameTimer(room.endsAt!);
      }

      // Check game end
      if (room.isFinished) {
        _showGameEndDialog();
      } else if (room.status == RoomStatus.abandoned) {
        _showAbandonedDialog();
      }
    });
  }

  void _startGameTimer(DateTime endsAt) {
    _gameTimer?.cancel();
    _remainingSeconds = endsAt.difference(DateTime.now()).inSeconds.clamp(0, 999);

    _gameTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_remainingSeconds > 0) {
        setState(() => _remainingSeconds--);
      } else {
        timer.cancel();
      }
    });
  }

  void _startFreeze(int seconds) {
    setState(() {
      _isFrozen = true;
      _freezeSeconds = seconds;
    });

    _freezeTimer?.cancel();
    _freezeTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_freezeSeconds > 0) {
        setState(() => _freezeSeconds--);
      } else {
        setState(() => _isFrozen = false);
        HapticFeedback.mediumImpact();
        timer.cancel();
      }
    });
  }

  Future<void> _submitSelection() async {
    if (_selectedSongId == null || _selectedArtist == null || !_isMyTurn || _isFrozen || _myUid == null) return;

    setState(() => _isSubmitting = true);
    HapticFeedback.mediumImpact();

    try {
      final result = await _gameService.submitSelection(
        roomId: widget.roomId,
        oderId: _myUid!,
        selectedSongId: _selectedSongId!,
      );

      if (result.isCorrect == true) {
        HapticFeedback.lightImpact();
        _showFeedback('Doğru! 🎉', const Color(0xFF4CAF50));
      } else {
        HapticFeedback.heavyImpact();
        _showFeedback('Yanlış! ❌', const Color(0xFFF85149));
        
        // Apply freeze based on mode
        if (_room?.modeVariant == ModeVariant.timeRace) {
          _startFreeze(3);
        } else if (_room?.modeVariant == ModeVariant.relax) {
          _startFreeze(1);
        }
      }

      setState(() {
        _selectedArtist = null;
        _selectedSongId = null;
      });
    } catch (e) {
      debugPrint('Error submitting selection: $e');
      _showFeedback('Hata oluştu', Colors.red);
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  void _showFeedback(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showGameEndDialog() {
    if (_room == null) return;

    final myPlayer = _room!.players[_myUid];
    final opponentUid = _room!.players.keys.firstWhere((uid) => uid != _myUid);
    final opponentPlayer = _room!.players[opponentUid];

    final myScore = myPlayer?.score ?? 0;
    final opponentScore = opponentPlayer?.score ?? 0;
    final won = myScore > opponentScore;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          won ? 'Kazandın! 🎉' : 'Kaybettin 😔',
          style: TextStyle(
            color: won ? const Color(0xFF4CAF50) : const Color(0xFFF85149),
            fontWeight: FontWeight.w800,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildScoreRow('Sen', myScore, won),
            const SizedBox(height: 8),
            _buildScoreRow(opponentPlayer?.name ?? 'Rakip', opponentScore, !won),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Kapat'),
          ),
        ],
      ),
    );
  }

  void _showAbandonedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Oyun Bitti'),
        content: const Text('Rakip oyundan ayrıldı.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreRow(String name, int score, bool isWinner) {
    return Row(
      children: [
        if (isWinner)
          const Icon(Icons.emoji_events, color: Color(0xFFFFB958), size: 20),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            name,
            style: TextStyle(
              fontSize: 16,
              fontWeight: isWinner ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
        Text(
          '$score',
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: isWinner ? const Color(0xFF4CAF50) : const Color(0xFF6C6FA4),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_room == null) {
      return Scaffold(
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFFE8E0FF), Color(0xFFF5F3FF)],
            ),
          ),
          child: const Center(child: CircularProgressIndicator()),
        ),
      );
    }

    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFFE8E0FF), Color(0xFFF5F3FF)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildWordCard(),
              const SizedBox(height: 16),
              _buildTurnIndicator(),
              const SizedBox(height: 16),
              Expanded(
                child: _isFrozen ? _buildFreezeOverlay() : _buildSelectionArea(),
              ),
              if (_selectedSongId != null && _selectedArtist != null && _isMyTurn && !_isFrozen)
                _buildConfirmButton(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    final myPlayer = _room!.players[_myUid];
    final opponentUid = _room!.players.keys.firstWhere((uid) => uid != _myUid);
    final opponentPlayer = _room!.players[opponentUid];

    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close, color: Color(0xFF394272)),
              ),
              const Spacer(),
              if (_room!.modeVariant == ModeVariant.timeRace && _remainingSeconds > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.red.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.timer, size: 16, color: Colors.red),
                      const SizedBox(width: 4),
                      Text(
                        _formatTime(_remainingSeconds),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: Colors.red,
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildPlayerCard(
                name: 'Sen',
                score: myPlayer?.score ?? 0,
                solved: myPlayer?.solvedCount ?? 0,
                isMe: true,
                isActive: _isMyTurn,
              ),
              Container(
                width: 2,
                height: 40,
                color: const Color(0xFFE0E0E0),
              ),
              _buildPlayerCard(
                name: opponentPlayer?.name ?? 'Rakip',
                score: opponentPlayer?.score ?? 0,
                solved: opponentPlayer?.solvedCount ?? 0,
                isMe: false,
                isActive: !_isMyTurn,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPlayerCard({
    required String name,
    required int score,
    required int solved,
    required bool isMe,
    required bool isActive,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isActive 
              ? const Color(0xFFCAB7FF).withValues(alpha: 0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: isActive 
              ? Border.all(color: const Color(0xFFCAB7FF), width: 2)
              : null,
        ),
        child: Column(
          children: [
            Text(
              name,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                color: const Color(0xFF394272),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            Text(
              'Puan: $score',
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Color(0xFF6C6FA4),
              ),
            ),
            Text(
              'Çözülen: $solved',
              style: TextStyle(
                fontSize: 11,
                color: const Color(0xFF6C6FA4).withValues(alpha: 0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWordCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFCAB7FF), Color(0xFFE0D6FF)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.15),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Text(
            'KELİME',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Color(0xFF6C6FA4),
              letterSpacing: 1.2,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            (_room?.currentWord ?? '').toUpperCase(),
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildTurnIndicator() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _isMyTurn 
            ? const Color(0xFFCAB7FF).withValues(alpha: 0.15)
            : Colors.grey.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isMyTurn ? Icons.play_circle_filled : Icons.hourglass_empty,
            color: _isMyTurn ? const Color(0xFFCAB7FF) : Colors.grey,
            size: 20,
          ),
          const SizedBox(width: 8),
          Text(
            _isMyTurn ? 'SENİN SIRAIN' : 'RAKIP OYNUYOR',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: _isMyTurn ? const Color(0xFF394272) : Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFreezeOverlay() {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(32),
        margin: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Colors.red.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.red, width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.pause_circle_filled, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'DONDU',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: Colors.red.shade700,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '$_freezeSeconds saniye',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w600,
                color: Color(0xFF394272),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSelectionArea() {
    // Get solved songs - note: we don't track per-player in current model
    // This is a simplification - you may need to add solvedSongIds to RoomPlayer
    final availableSongs = _songs
        .map((s) => SongItem(
              id: s.id,
              artist: s.artist,
              title: s.title,
            ))
        .toList();

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: DualColumnSelector(
        artists: _artists,
        songs: availableSongs,
        selectedArtist: _selectedArtist,
        selectedSongId: _selectedSongId,
        onArtistSelected: (artist) {
          if (_isMyTurn && !_isFrozen) {
            setState(() {
              _selectedArtist = artist;
              _selectedSongId = null;
            });
            HapticFeedback.selectionClick();
          }
        },
        onSongSelected: (songId) {
          if (_isMyTurn && !_isFrozen) {
            setState(() => _selectedSongId = songId);
            HapticFeedback.selectionClick();
          }
        },
        disabled: !_isMyTurn || _isFrozen || _isSubmitting,
      ),
    );
  }

  Widget _buildConfirmButton() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCAB7FF).withValues(alpha: 0.4),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: SizedBox(
          width: double.infinity,
          height: 56,
          child: ElevatedButton(
            onPressed: _isSubmitting ? null : _submitSelection,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFCAB7FF),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 0,
            ),
            child: _isSubmitting
                ? const SizedBox(
                    width: 24,
                    height: 24,
                    child: CircularProgressIndicator(
                      color: Color(0xFF394272),
                      strokeWidth: 3,
                    ),
                  )
                : const Text(
                    'EŞLEŞTİRMEYİ ONAYLA',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF394272),
                      letterSpacing: 0.5,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  String _formatTime(int seconds) {
    final m = seconds ~/ 60;
    final s = seconds % 60;
    return '$m:${s.toString().padLeft(2, '0')}';
  }
}
