
/// Oyun ayarları için kullanılan enum'lar
enum SongMode { single, multiple }
enum EndCondition { songCount, time }
