import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/game_room_model.dart';
import '../../services/friends_online_game_service.dart';

/// Friends Online Word Game with improved turn-based UX
/// - Dramatic reviewer countdown with auto-approve
/// - Tension-building waiting states
/// - Time pressure visualization
/// - Clear feedback after actions
class FriendsWordGameScreen extends StatefulWidget {
  final String roomId;

  const FriendsWordGameScreen({super.key, required this.roomId});

  @override
  State<FriendsWordGameScreen> createState() => _FriendsWordGameScreenState();
}

class _FriendsWordGameScreenState extends State<FriendsWordGameScreen>
    with TickerProviderStateMixin {
  final _gameService = FriendsOnlineGameService();
  final _songController = TextEditingController();
  final _artistController = TextEditingController();
  final _songFocus = FocusNode();
  final _artistFocus = FocusNode();

  StreamSubscription<GameRoomModel?>? _roomSubscription;
  GameRoomModel? _room;
  List<FriendsWordRound> _rounds = [];
  bool _isSubmitting = false;
  bool _hasSubmittedAnswer = false;
  bool _hasSubmittedReview = false;
  Timer? _reviewTimer;
  int _reviewSecondsLeft = 5;

  // Animations
  late AnimationController _pulseController;
  late AnimationController _shakeController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _shakeAnimation;

  // Feedback state
  String? _feedbackMessage;
  Color? _feedbackColor;
  bool _showFeedback = false;

  String? get _myUid => context.read<AuthProvider>().user?.uid;

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _listenToRoom();
    _listenToRounds();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _shakeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _shakeAnimation = Tween<double>(begin: 0, end: 10).animate(
      CurvedAnimation(parent: _shakeController, curve: Curves.elasticIn),
    );
  }

  @override
  void dispose() {
    _roomSubscription?.cancel();
    _reviewTimer?.cancel();
    _songController.dispose();
    _artistController.dispose();
    _songFocus.dispose();
    _artistFocus.dispose();
    _pulseController.dispose();
    _shakeController.dispose();
    super.dispose();
  }

  void _listenToRoom() {
    _roomSubscription = _gameService.streamRoom(widget.roomId).listen((room) {
      if (room == null) return;

      final previousPhase = _room?.phase;
      setState(() => _room = room);

      if (room.isFinished) {
        _showGameEndDialog();
      } else if (room.status == RoomStatus.abandoned) {
        _showAbandonedDialog();
      }

      // Reset submission states on phase change
      if (previousPhase != room.phase) {
        setState(() {
          _hasSubmittedAnswer = false;
          _hasSubmittedReview = false;
          _showFeedback = false;
        });
      }

      // Start review timer if in reviewing phase
      if (room.phase == GamePhase.reviewing && room.reviewDeadlineAt != null) {
        _startReviewTimer(room.reviewDeadlineAt!);
      }
    });
  }

  void _listenToRounds() {
    _gameService.streamRounds(widget.roomId).listen((rounds) {
      setState(() => _rounds = rounds);
    });
  }

  void _startReviewTimer(DateTime deadline) {
    _reviewTimer?.cancel();
    final remaining = deadline.difference(DateTime.now());
    _reviewSecondsLeft = remaining.inSeconds.clamp(0, 5);

    _reviewTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_reviewSecondsLeft > 0) {
        setState(() => _reviewSecondsLeft--);
        
        // Haptic on last 3 seconds
        if (_reviewSecondsLeft <= 3) {
          HapticFeedback.lightImpact();
        }
      } else {
        timer.cancel();
      }
    });
  }

  Future<void> _submitAnswer() async {
    final song = _songController.text.trim();
    final artist = _artistController.text.trim();

    if (song.isEmpty || artist.isEmpty) {
      _shakeController.forward(from: 0);
      HapticFeedback.heavyImpact();
      _showFeedbackBanner('Şarkı ve sanatçı adını gir!', const Color(0xFFFF6B6B));
      return;
    }

    setState(() {
      _isSubmitting = true;
      _hasSubmittedAnswer = true;
    });

    HapticFeedback.mediumImpact();

    try {
      await _gameService.submitAnswer(
        roomId: widget.roomId,
        oderId: _myUid!,
        song: song,
        artist: artist,
      );
      
      _showFeedbackBanner('Cevap gönderildi! ✓', const Color(0xFF4CAF50));
      _songController.clear();
      _artistController.clear();
    } catch (e) {
      setState(() => _hasSubmittedAnswer = false);
      _showFeedbackBanner('Hata oluştu', const Color(0xFFF85149));
    } finally {
      setState(() => _isSubmitting = false);
    }
  }

  Future<void> _submitReview(bool approved) async {
    setState(() => _hasSubmittedReview = true);
    HapticFeedback.mediumImpact();

    try {
      await _gameService.submitReview(
        roomId: widget.roomId,
        reviewerUid: _myUid!,
        approved: approved,
      );

      _showFeedbackBanner(
        approved ? 'Onaylandı! ✓' : 'Reddedildi ✗',
        approved ? const Color(0xFF4CAF50) : const Color(0xFFF85149),
      );
    } catch (e) {
      setState(() => _hasSubmittedReview = false);
      _showFeedbackBanner('Hata oluştu', const Color(0xFFF85149));
    }
  }

  void _showFeedbackBanner(String message, Color color) {
    setState(() {
      _feedbackMessage = message;
      _feedbackColor = color;
      _showFeedback = true;
    });

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => _showFeedback = false);
      }
    });
  }

  void _showGameEndDialog() {
    if (_room == null) return;

    final myPlayer = _room!.getPlayer(_myUid!);
    final opponent = _room!.otherPlayer;
    final myScore = myPlayer?.score ?? 0;
    final opponentScore = opponent?.score ?? 0;

    String emoji;
    String resultText;
    Color resultColor;
    List<Color> bgGradient;

    if (myScore > opponentScore) {
      emoji = '🏆';
      resultText = 'Kazandın!';
      resultColor = const Color(0xFF4CAF50);
      bgGradient = [const Color(0xFF4CAF50), const Color(0xFF66BB6A)];
    } else if (myScore < opponentScore) {
      emoji = '😔';
      resultText = 'Kaybettin';
      resultColor = const Color(0xFFF85149);
      bgGradient = [const Color(0xFFF85149), const Color(0xFFFF7B6B)];
    } else {
      emoji = '🤝';
      resultText = 'Berabere';
      resultColor = const Color(0xFFFFB958);
      bgGradient = [const Color(0xFFFFB958), const Color(0xFFFFCE54)];
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        child: Container(
          padding: const EdgeInsets.all(28),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: bgGradient),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(emoji, style: const TextStyle(fontSize: 40)),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                resultText,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: resultColor,
                ),
              ),
              const SizedBox(height: 24),
              _buildResultScoreRow('Sen', myScore, myScore > opponentScore),
              const SizedBox(height: 12),
              _buildResultScoreRow(opponent?.name ?? 'Rakip', opponentScore, opponentScore > myScore),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pop();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF394272),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text(
                    'Ana Menü',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildResultScoreRow(String name, int score, bool isWinner) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isWinner ? const Color(0xFFE8F5E9) : const Color(0xFFF5F5F5),
        borderRadius: BorderRadius.circular(12),
        border: isWinner ? Border.all(color: const Color(0xFF4CAF50).withValues(alpha:0.3)) : null,
      ),
      child: Row(
        children: [
          if (isWinner)
            const Text('🏆 ', style: TextStyle(fontSize: 18)),
          Expanded(
            child: Text(
              name,
              style: TextStyle(
                fontSize: 16,
                fontWeight: isWinner ? FontWeight.w700 : FontWeight.w500,
                color: const Color(0xFF394272),
              ),
            ),
          ),
          Text(
            '$score',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: isWinner ? const Color(0xFF4CAF50) : const Color(0xFF6C6FA4),
            ),
          ),
        ],
      ),
    );
  }

  void _showAbandonedDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            const Text('🚪', style: TextStyle(fontSize: 24)),
            const SizedBox(width: 10),
            const Text('Rakip Ayrıldı'),
          ],
        ),
        content: const Text('Rakip oyundan ayrıldı. Maç sona erdi.'),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Navigator.of(context).pop();
            },
            child: const Text('Tamam'),
          ),
        ],
      ),
    );
  }

  Future<void> _leaveGame() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Row(
          children: [
            const Text('🚪', style: TextStyle(fontSize: 24)),
            const SizedBox(width: 10),
            const Text('Oyundan Çık'),
          ],
        ),
        content: const Text('Oyundan çıkarsan maçı kaybedersin.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Devam Et'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: const Color(0xFFF85149)),
            child: const Text('Çık'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _gameService.leaveGame(widget.roomId, _myUid!);
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_room == null) {
      return Scaffold(
        backgroundColor: const Color(0xFFF5F0FF),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(color: Color(0xFFCAB7FF)),
              const SizedBox(height: 16),
              Text(
                'Oyun yükleniyor...',
                style: TextStyle(
                  color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      );
    }

    final isMyTurn = _room!.turnUid == _myUid;
    final myPlayer = _room!.getPlayer(_myUid!);
    final opponent = _room!.otherPlayer;

    return Scaffold(
      backgroundColor: const Color(0xFFF5F0FF),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            _buildScoreBar(myPlayer, opponent),
            _buildWordDisplay(),
            
            // Feedback banner
            if (_showFeedback)
              _buildFeedbackBanner(),

            // Game area
            Expanded(
              child: _room!.phase == GamePhase.reviewing
                  ? _buildReviewingPhase()
                  : _buildAnsweringPhase(isMyTurn),
            ),

            // History
            _buildHistory(),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        children: [
          GestureDetector(
            onTap: _leaveGame,
            child: Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha:0.06),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: const Icon(Icons.close, size: 20, color: Color(0xFF394272)),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Text(
              'Arkadaşla Online',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: Color(0xFF394272),
              ),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFFCAB7FF), Color(0xFF9B7EDE)],
              ),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              'Tur ${_room!.roundIndex + 1}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w700,
                fontSize: 13,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScoreBar(RoomPlayer? myPlayer, RoomPlayer? opponent) {
    final isMyTurn = _room!.turnUid == _myUid;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha:0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // My score
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: isMyTurn ? const Color(0xFFCAB7FF).withValues(alpha:0.15) : null,
                borderRadius: BorderRadius.circular(12),
                border: isMyTurn ? Border.all(color: const Color(0xFFCAB7FF), width: 2) : null,
              ),
              child: Column(
                children: [
                  Text(
                    'Sen',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${myPlayer?.score ?? 0}',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF394272),
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Container(
              width: 2,
              height: 50,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(1),
              ),
            ),
          ),
          
          // Opponent score
          Expanded(
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 8),
              decoration: BoxDecoration(
                color: !isMyTurn ? const Color(0xFFFFB958).withValues(alpha:0.15) : null,
                borderRadius: BorderRadius.circular(12),
                border: !isMyTurn ? Border.all(color: const Color(0xFFFFB958), width: 2) : null,
              ),
              child: Column(
                children: [
                  Text(
                    opponent?.name ?? 'Rakip',
                    style: TextStyle(
                      color: Colors.grey.shade600,
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${opponent?.score ?? 0}',
                    style: const TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFFFFB958),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWordDisplay() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        final isMyTurn = _room!.turnUid == _myUid;
        return Transform.scale(
          scale: isMyTurn && _room!.phase == GamePhase.answering ? _pulseAnimation.value : 1.0,
          child: child,
        );
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        margin: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFCAB7FF), Color(0xFF9B7EDE)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFFCAB7FF).withValues(alpha:0.4),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha:0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                '🎯 KELİME',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              _room!.currentWord.toUpperCase(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 40,
                fontWeight: FontWeight.w900,
                letterSpacing: 4,
                shadows: [
                  Shadow(
                    color: Colors.black26,
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFeedbackBanner() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: _feedbackColor?.withValues(alpha:0.15),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _feedbackColor?.withValues(alpha:0.3) ?? Colors.grey),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            _feedbackMessage ?? '',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w700,
              color: _feedbackColor,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnsweringPhase(bool isMyTurn) {
    if (!isMyTurn) {
      return _buildWaitingForOpponent();
    }

    if (_hasSubmittedAnswer) {
      return _buildAnswerSubmitted();
    }

    return _buildAnswerInput();
  }

  Widget _buildWaitingForOpponent() {
    final opponentName = _room!.currentTurnPlayer?.name ?? 'Rakip';

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Animated opponent indicator
            Stack(
              alignment: Alignment.center,
              children: [
                // Pulse rings
                AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Container(
                      width: 120 * _pulseAnimation.value,
                      height: 120 * _pulseAnimation.value,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: const Color(0xFFFFB958).withValues(alpha:0.3),
                          width: 2,
                        ),
                      ),
                    );
                  },
                ),
                Container(
                  width: 90,
                  height: 90,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFB958), Color(0xFFFFCE54)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFFB958).withValues(alpha:0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 6),
                      ),
                    ],
                  ),
                  child: const Center(
                    child: Text('🎤', style: TextStyle(fontSize: 40)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 28),
            Text(
              '$opponentName düşünüyor...',
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: Color(0xFF394272),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Cevabını bekle',
              style: TextStyle(
                fontSize: 14,
                color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
              ),
            ),
            const SizedBox(height: 24),
            // Animated dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (index) {
                return AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    final delay = index * 0.2;
                    final value = (_pulseController.value + delay) % 1.0;
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFB958).withValues(alpha:0.3 + (value * 0.7)),
                        shape: BoxShape.circle,
                      ),
                    );
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerSubmitted() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: const Color(0xFF4CAF50).withValues(alpha:0.15),
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_rounded,
                size: 50,
                color: Color(0xFF4CAF50),
              ),
            ),
            const SizedBox(height: 24),
            const Text(
              'Cevap Gönderildi!',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.w800,
                color: Color(0xFF4CAF50),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Rakibin değerlendirmesi bekleniyor...',
              style: TextStyle(
                fontSize: 14,
                color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerInput() {
    return AnimatedBuilder(
      animation: _shakeAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(_shakeAnimation.value * ((_shakeController.value * 10).toInt() % 2 == 0 ? 1 : -1), 0),
          child: child,
        );
      },
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // Turn indicator
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFFCAB7FF), Color(0xFF9B7EDE)],
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('🎯', style: TextStyle(fontSize: 18)),
                  const SizedBox(width: 8),
                  const Text(
                    'Senin Sıran!',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Song input
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha:0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextField(
                controller: _songController,
                focusNode: _songFocus,
                textInputAction: TextInputAction.next,
                onSubmitted: (_) => _artistFocus.requestFocus(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF394272),
                ),
                decoration: InputDecoration(
                  labelText: 'Şarkı Adı',
                  labelStyle: TextStyle(
                    color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
                    fontWeight: FontWeight.w500,
                  ),
                  prefixIcon: const Icon(Icons.music_note, color: Color(0xFFCAB7FF)),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: Color(0xFFCAB7FF), width: 2),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Artist input
            Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha:0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: TextField(
                controller: _artistController,
                focusNode: _artistFocus,
                textInputAction: TextInputAction.done,
                onSubmitted: (_) => _submitAnswer(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Color(0xFF394272),
                ),
                decoration: InputDecoration(
                  labelText: 'Sanatçı',
                  labelStyle: TextStyle(
                    color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
                    fontWeight: FontWeight.w500,
                  ),
                  prefixIcon: const Icon(Icons.mic, color: Color(0xFFCAB7FF)),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide(color: Colors.grey.shade200),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: const BorderSide(color: Color(0xFFCAB7FF), width: 2),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Submit button
            SizedBox(
              width: double.infinity,
              height: 58,
              child: ElevatedButton(
                onPressed: _isSubmitting ? null : _submitAnswer,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF394272),
                  disabledBackgroundColor: const Color(0xFF394272).withValues(alpha:0.5),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(18),
                  ),
                  elevation: 4,
                  shadowColor: const Color(0xFF394272).withValues(alpha:0.3),
                ),
                child: _isSubmitting
                    ? const SizedBox(
                        height: 24,
                        width: 24,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5),
                      )
                    : const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.send_rounded, color: Colors.white, size: 22),
                          SizedBox(width: 10),
                          Text(
                            'Gönder',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReviewingPhase() {
    final isReviewer = _room!.turnUid != _myUid;
    final currentRound = _rounds.isNotEmpty ? _rounds.first : null;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Countdown timer with drama
          _buildReviewTimer(),
          const SizedBox(height: 24),

          // Answer display
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha:0.06),
                  blurRadius: 16,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Column(
              children: [
                Text(
                  'Verilen Cevap',
                  style: TextStyle(
                    color: Colors.grey.shade500,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  currentRound?.answerSong ?? '-',
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF394272),
                  ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 4),
                Text(
                  currentRound?.answerArtist ?? '-',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF6C6FA4),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          if (isReviewer && !_hasSubmittedReview) ...[
            const Text(
              'Bu cevap doğru mu?',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: Color(0xFF394272),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Süre bitince otomatik onaylanır',
              style: TextStyle(
                fontSize: 12,
                color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 54,
                    child: ElevatedButton.icon(
                      onPressed: () => _submitReview(false),
                      icon: const Icon(Icons.close_rounded, size: 22),
                      label: const Text('Reddet', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFF85149),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 2,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: SizedBox(
                    height: 54,
                    child: ElevatedButton.icon(
                      onPressed: () => _submitReview(true),
                      icon: const Icon(Icons.check_rounded, size: 22),
                      label: const Text('Onayla', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF4CAF50),
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 2,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ] else if (_hasSubmittedReview) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFF4CAF50).withValues(alpha:0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.check_circle, color: Color(0xFF4CAF50), size: 20),
                  SizedBox(width: 8),
                  Text(
                    'Değerlendirme gönderildi',
                    style: TextStyle(
                      color: Color(0xFF4CAF50),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              decoration: BoxDecoration(
                color: const Color(0xFFFFB958).withValues(alpha:0.1),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Color(0xFFFFB958),
                    ),
                  ),
                  SizedBox(width: 10),
                  Text(
                    'Rakip değerlendiriyor...',
                    style: TextStyle(
                      color: Color(0xFFFFB958),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildReviewTimer() {
    final isUrgent = _reviewSecondsLeft <= 2;

    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: isUrgent ? _pulseAnimation.value : 1.0,
          child: child,
        );
      },
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isUrgent
                ? [const Color(0xFFF85149), const Color(0xFFFF7B6B)]
                : [const Color(0xFFFFB958), const Color(0xFFFFCE54)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: (isUrgent ? const Color(0xFFF85149) : const Color(0xFFFFB958)).withValues(alpha:0.4),
              blurRadius: 16,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: Center(
          child: Text(
            '$_reviewSecondsLeft',
            style: const TextStyle(
              fontSize: 36,
              fontWeight: FontWeight.w900,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHistory() {
    if (_rounds.isEmpty) return const SizedBox.shrink();

    final resolvedRounds = _rounds.where((r) => r.resolved).take(5).toList();
    if (resolvedRounds.isEmpty) return const SizedBox.shrink();

    return Container(
      height: 90,
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: resolvedRounds.length,
        itemBuilder: (context, index) {
          final round = resolvedRounds[index];
          final isMyRound = round.turnUid == _myUid;
          final isAccepted = round.isAccepted ?? false;

          return Container(
            width: 110,
            margin: const EdgeInsets.only(right: 10),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: isAccepted ? const Color(0xFFE8F5E9) : const Color(0xFFFFEBEE),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: isAccepted 
                    ? const Color(0xFF4CAF50).withValues(alpha:0.3) 
                    : const Color(0xFFF85149).withValues(alpha:0.3),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      isAccepted ? Icons.check_circle : Icons.cancel,
                      size: 14,
                      color: isAccepted ? const Color(0xFF4CAF50) : const Color(0xFFF85149),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      isMyRound ? 'Sen' : 'Rakip',
                      style: TextStyle(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Text(
                  round.word.toUpperCase(),
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 11,
                    color: Color(0xFF394272),
                  ),
                ),
                Text(
                  round.answerSong ?? '-',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.grey.shade600,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
