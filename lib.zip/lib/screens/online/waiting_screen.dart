import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../../models/match_intent_model.dart';
import '../../services/matchmaking_service.dart';
import 'friends_word_game_screen.dart';
import '../challenge/challenge_online_screen.dart';

/// Waiting Screen with engaging UX
/// - Animated waiting state that feels alive
/// - "Davet" language instead of "ID"
/// - Confidence-building micro-copy
/// - Strong share action with feedback
/// - Soft cancel flow
/// - Smooth transition to match found
class WaitingScreen extends StatefulWidget {
  final String intentId;
  final String myPlayerId;
  final String opponentPlayerId;
  final MatchMode mode;
  final String? challengeName;

  const WaitingScreen({
    super.key,
    required this.intentId,
    required this.myPlayerId,
    required this.opponentPlayerId,
    required this.mode,
    this.challengeName,
  });

  @override
  State<WaitingScreen> createState() => _WaitingScreenState();
}

class _WaitingScreenState extends State<WaitingScreen>
    with TickerProviderStateMixin {
  final _matchmakingService = MatchmakingService();
  StreamSubscription<MatchIntentModel?>? _intentSubscription;
  
  late AnimationController _pulseController;
  late AnimationController _rotationController;
  late AnimationController _dotController;
  late AnimationController _matchFoundController;
  
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotationAnimation;
  late Animation<double> _matchFoundAnimation;
  
  bool _isCanceling = false;
  bool _matchFound = false;
  int _waitingSeconds = 0;
  Timer? _waitingTimer;
  int _currentTipIndex = 0;
  Timer? _tipTimer;

  final List<String> _waitingTips = [
    '🎵 Arkadaşın kodunu girince eşleşeceksiniz',
    '📱 Davet linkini tekrar paylaşabilirsin',
    '⏱️ Eşleşme 5 dakika içinde gerçekleşmezse iptal olur',
    '🎮 Her iki taraf da hazır olunca oyun başlar',
    '💡 İpucu: WhatsApp ile link paylaş, en hızlısı!',
  ];

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _listenToIntent();
    _startWaitingTimer();
    _startTipRotation();
  }

  void _initAnimations() {
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.15).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _rotationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _rotationAnimation = Tween<double>(begin: 0, end: 1).animate(_rotationController);

    _dotController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();

    _matchFoundController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _matchFoundAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _matchFoundController, curve: Curves.elasticOut),
    );
  }

  @override
  void dispose() {
    _intentSubscription?.cancel();
    _pulseController.dispose();
    _rotationController.dispose();
    _dotController.dispose();
    _matchFoundController.dispose();
    _waitingTimer?.cancel();
    _tipTimer?.cancel();
    super.dispose();
  }

  void _startWaitingTimer() {
    _waitingTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() => _waitingSeconds++);
      }
    });
  }

  void _startTipRotation() {
    _tipTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) {
        setState(() {
          _currentTipIndex = (_currentTipIndex + 1) % _waitingTips.length;
        });
      }
    });
  }

  void _listenToIntent() {
    _intentSubscription = _matchmakingService.streamIntent(widget.intentId).listen((intent) {
      if (intent == null) return;

      if (intent.isPaired && intent.roomId != null) {
        _onMatchFound(intent.roomId!);
      } else if (intent.isCanceled) {
        _showStatusDialog(
          emoji: '❌',
          title: 'Davet İptal Edildi',
          message: 'Davet iptal edildi.',
          buttonText: 'Tamam',
        );
      } else if (intent.isExpired) {
        _showStatusDialog(
          emoji: '⏱️',
          title: 'Süre Doldu',
          message: 'Eşleşme süresi doldu. Tekrar dene!',
          buttonText: 'Tamam',
        );
      }
    });
  }

  void _onMatchFound(String roomId) {
    setState(() => _matchFound = true);
    _matchFoundController.forward();
    HapticFeedback.heavyImpact();

    Future.delayed(const Duration(milliseconds: 1200), () {
      _navigateToGame(roomId);
    });
  }

  void _navigateToGame(String roomId) {
    Widget gameScreen;
    if (widget.mode == MatchMode.friendsWord) {
      gameScreen = FriendsWordGameScreen(roomId: roomId);
    } else {
      gameScreen = ChallengeOnlineScreen(roomId: roomId);
    }

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        pageBuilder: (context, animation, secondaryAnimation) => gameScreen,
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          return FadeTransition(
            opacity: animation,
            child: ScaleTransition(
              scale: Tween<double>(begin: 0.95, end: 1.0).animate(animation),
              child: child,
            ),
          );
        },
        transitionDuration: const Duration(milliseconds: 400),
      ),
    );
  }

  void _showStatusDialog({
    required String emoji,
    required String title,
    required String message,
    required String buttonText,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(emoji, style: const TextStyle(fontSize: 48)),
              const SizedBox(height: 16),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF394272),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
                ),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                    Navigator.of(context).pop();
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF394272),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                  child: Text(
                    buttonText,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _cancelMatch() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Row(
          children: [
            Text('⏸️', style: TextStyle(fontSize: 24)),
            SizedBox(width: 10),
            Text('Beklemekten Vazgeç'),
          ],
        ),
        content: const Text('Eşleşme beklemeyi iptal etmek istediğine emin misin?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Beklemeye Devam'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: const Color(0xFFF85149)),
            child: const Text('Vazgeç'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => _isCanceling = true);

    try {
      await _matchmakingService.cancelIntent(widget.intentId);
      if (mounted) {
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isCanceling = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('İptal edilemedi: $e'),
            backgroundColor: const Color(0xFFF85149),
          ),
        );
      }
    }
  }

  void _shareInvite() {
    HapticFeedback.lightImpact();
    
    final link = 'find2sing://match?opponentId=${widget.myPlayerId}';
    final modeText = widget.mode == MatchMode.challengeOnline
        ? (widget.challengeName ?? 'Challenge')
        : 'Arkadaşla Oyna';
    
    Share.share(
      '🎵 Find2Sing\'de $modeText modunda benimle oyna!\n\n'
      '📋 Davet Kodum: ${widget.myPlayerId}\n\n'
      '🔗 $link',
      subject: 'Find2Sing Davet',
    );
  }

  void _copyCode() {
    Clipboard.setData(ClipboardData(text: widget.myPlayerId));
    HapticFeedback.lightImpact();
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            const Icon(Icons.check_circle, color: Colors.white, size: 20),
            const SizedBox(width: 10),
            const Text('Davet kodu kopyalandı!'),
          ],
        ),
        backgroundColor: const Color(0xFF4CAF50),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  String _formatWaitingTime() {
    final minutes = _waitingSeconds ~/ 60;
    final seconds = _waitingSeconds % 60;
    if (minutes > 0) {
      return '$minutes dk ${seconds.toString().padLeft(2, '0')} sn';
    }
    return '$seconds saniye';
  }

  @override
  Widget build(BuildContext context) {
    if (_matchFound) {
      return _buildMatchFoundScreen();
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF5F0FF),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              // Header with challenge badge
              if (widget.mode == MatchMode.challengeOnline && widget.challengeName != null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFB958).withValues(alpha:0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('⚔️', style: TextStyle(fontSize: 14)),
                      const SizedBox(width: 6),
                      Text(
                        widget.challengeName!,
                        style: const TextStyle(
                          color: Color(0xFFFFB958),
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ),
                ),

              const Spacer(),

              // Animated waiting indicator
              _buildAnimatedIndicator(),

              const SizedBox(height: 32),

              // Title
              const Text(
                'Arkadaşın Bekleniyor',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF394272),
                ),
              ),

              const SizedBox(height: 12),

              // Waiting time
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0xFFCAB7FF).withValues(alpha:0.15),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.timer_outlined, color: Color(0xFFCAB7FF), size: 18),
                    const SizedBox(width: 8),
                    Text(
                      _formatWaitingTime(),
                      style: const TextStyle(
                        color: Color(0xFFCAB7FF),
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // My code card
              _buildMyCodeCard(),

              const SizedBox(height: 20),

              // Rotating tips
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 400),
                child: Container(
                  key: ValueKey(_currentTipIndex),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha:0.7),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    _waitingTips[_currentTipIndex],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
                      fontSize: 13,
                    ),
                  ),
                ),
              ),

              const Spacer(),

              // Share button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _shareInvite,
                  icon: const Icon(Icons.share_rounded, color: Colors.white),
                  label: const Text(
                    'Daveti Tekrar Paylaş',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFCAB7FF),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                    elevation: 4,
                    shadowColor: const Color(0xFFCAB7FF).withValues(alpha:0.4),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // Cancel button
              TextButton(
                onPressed: _isCanceling ? null : _cancelMatch,
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                ),
                child: _isCanceling
                    ? const SizedBox(
                        height: 20,
                        width: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Color(0xFF6C6FA4),
                        ),
                      )
                    : Text(
                        'Beklemekten Vazgeç',
                        style: TextStyle(
                          color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
              ),

              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildAnimatedIndicator() {
    return Stack(
      alignment: Alignment.center,
      children: [
        // Outer rotating ring
        AnimatedBuilder(
          animation: _rotationAnimation,
          builder: (context, child) {
            return Transform.rotate(
              angle: _rotationAnimation.value * 2 * 3.14159,
              child: Container(
                width: 160,
                height: 160,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFCAB7FF).withValues(alpha:0.2),
                    width: 3,
                  ),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      left: 70,
                      child: Container(
                        width: 12,
                        height: 12,
                        decoration: const BoxDecoration(
                          color: Color(0xFFCAB7FF),
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),

        // Pulsing inner circle
        AnimatedBuilder(
          animation: _pulseAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _pulseAnimation.value,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFCAB7FF).withValues(alpha:0.2),
                ),
              ),
            );
          },
        ),

        // Center icon
        Container(
          width: 80,
          height: 80,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [Color(0xFFCAB7FF), Color(0xFF9B7EDE)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: const Center(
            child: Text('👥', style: TextStyle(fontSize: 36)),
          ),
        ),

        // Animated dots
        Positioned(
          bottom: 10,
          child: AnimatedBuilder(
            animation: _dotController,
            builder: (context, child) {
              return Row(
                mainAxisSize: MainAxisSize.min,
                children: List.generate(3, (index) {
                  final delay = index * 0.3;
                  final value = ((_dotController.value + delay) % 1.0);
                  final opacity = value < 0.5 ? value * 2 : (1 - value) * 2;
                  return Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: const Color(0xFFCAB7FF).withValues(alpha:0.3 + (opacity * 0.7)),
                      shape: BoxShape.circle,
                    ),
                  );
                }),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMyCodeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha:0.05),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(
            'Senin Davet Kodun',
            style: TextStyle(
              color: const Color(0xFF6C6FA4).withValues(alpha:0.7),
              fontSize: 12,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                widget.myPlayerId,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  color: Color(0xFF394272),
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 12),
              GestureDetector(
                onTap: _copyCode,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFCAB7FF).withValues(alpha:0.15),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.copy_rounded,
                    color: Color(0xFFCAB7FF),
                    size: 18,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMatchFoundScreen() {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F0FF),
      body: Center(
        child: AnimatedBuilder(
          animation: _matchFoundAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _matchFoundAnimation.value,
              child: Opacity(
                opacity: _matchFoundAnimation.value,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 120,
                      height: 120,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFF4CAF50), Color(0xFF66BB6A)],
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF4CAF50).withValues(alpha:0.4),
                            blurRadius: 24,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: const Center(
                        child: Text('🎮', style: TextStyle(fontSize: 56)),
                      ),
                    ),
                    const SizedBox(height: 28),
                    const Text(
                      'Eşleşme Bulundu!',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF4CAF50),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Oyun başlıyor...',
                      style: TextStyle(
                        fontSize: 16,
                        color: const Color(0xFF6C6FA4).withValues(alpha:0.8),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
